<script>

           $(document).ready(function(){
          
           $(document).on('click','button.like',function(){


                var cid="<?php  echo $this->session->userdata['profile_data'][0]['custID'];   ?>";
                var catid=$(this).attr('id');
               
                var cat="FORUM";
                var act="LIKE";
                var page="recentactivity";
 var countid= $(this).children('span').html();

                var pid=$(".user"+catid).attr('id');
                $.ajax({
                    url: "<?php echo base_url();?>like?cid="+cid+"&& uid="+pid+"&& cat="+cat+"&& act="+act+"&& page="+page+"&catid="+catid,
                    
                }).done(function( data ) {


                    $("#user_like"+catid).load('<?php echo base_url(); ?>forum/recent_like_count?id_forum='+catid);
                    return true;
                });



});

           });

        </script>
 <script>
           $(document).ready(function(){
           
           $(document).on('click','button.comment',function(){

 var pid=$(this).attr('id');
$(this).hide();
                var comment_user = $("#user_comment"+pid).val();

                if(comment_user == "")
                {
                    $("#user_comment"+pid).focus();

                }
                else
                {
                    var user_comment = $("#user_comment"+pid).val();
                    var uid = $(".user"+pid).attr('id');
                    var cid = "<?php echo $this->session->userdata['profile_data'][0]['custID'];  ?>";
                   
                    var cat="FORUM";

                    var act="DISCOMMENT";
                   
                    if(user_comment!=''){
                        $.ajax({
                            url: "<?php echo base_url();?>activity?user_comment="+user_comment+"&uid="+uid+"&cid="+cid+"&pid="+pid+"&cat="+cat+"&act="+act
                        }).done(function( data ) {

                            return true;
                        });

                        $.ajax({
                            url: "<?php echo base_url();?>forum/recent_comments"

                        }).done(function( result ) {
                            $("#recent_comment"+pid).load('<?php echo base_url(); ?>forum/recent_comments?id_forum='+pid);
                            $("#user_comment"+pid).val('');


                            return true;
                        });
                        $.ajax({
                            url: "<?php echo base_url();?>forum/recent_comment_count"
                        }).done(function( result ) {
                            $("#recent_comment_count"+pid).load('<?php echo base_url(); ?>forum/recent_comment_count?id_forum='+pid);


                            return true;
                        });



                    }


                }
                $(this).show();
            });
            });

        </script>