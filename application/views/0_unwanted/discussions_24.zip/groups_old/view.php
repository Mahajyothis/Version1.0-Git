<!DOCTYPE html>
<html lang="en">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<meta charset="utf-8">
		<title><?=$results->grp_name;?></title>
		<meta name="generator" content="Bootply" >
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
		<!--[if lt IE 9]>
			<script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->

		<link href="<?php echo base_url('assets/group_rakesh/css/styles.css');?>" rel="stylesheet">
		<link href="<?php echo base_url('assets/group_rakesh/css/jquery-ui.css');?>" rel="stylesheet">
		<link href="<?php echo base_url('assets/css/jquery.autocomplete.css');?>" rel="stylesheet">

        <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
        <script src="https://code.jquery.com/jquery-1.7.1.min.js"></script>
        <script src="http://code.jquery.com/jquery-1.8.3.min.js"></script>
	</head>
	<body>
 
<?php $countData = count($userData);
      $Countmembers =  count($members);
	  //print_r($members);
 ?>
<div class="container">
  <div class="col-md-12 back" style="background-image:url(<?php echo base_url().'uploads/groups/banners/'.$results->grp_cover;?>) !important;">
  
	<div class="col-md-12 navigate">
	<!--navigations-->
		<div class="col-md-6 navigation_no_bg" style="width: 45%;">
			<div class="col-md-12">
				<h4 style="margin-top: 5px;color:white">
                <?=$results->grp_name;?></h4>
		    </div>	
			
			<div class="col-md-12">
				<h6 style="margin-top: 0px;color:#15CA15;">
<?php if($results->privacy ==1)echo "Public";else{echo "Private";}?> Group</h6>
		    </div>				
		</div>
		
		<div class="col-md-2 navigation_no_bg" style="text-align: center;padding: 1%;">
			&nbsp;
		</div>	
		
		<div class="col-md-2 navigation_no_bg" style="text-align: center;padding: 1%;">
			<div class="dropdown">
				<!--  <button class="btn btn-default transperantb dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
					<span class="caret"></span>  Notifications on
				  </button>
				  <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
					<li><a href="#">Notifications off</a></li>
				  </ul> -->
				  &nbsp;
			</div>
		
		</div>
		
		
		<div class="col-md-2 navigation_no_bg" style="text-align: center;padding: 1%;">
			<div class="dropdown">
				 <!--  <button class="btn btn-default transperantb dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
					<span class="caret"></span>  Settings
				  </button>
				  <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
					<li><a href="#">Action</a></li>
					<li><a href="#">Another action</a></li>
					<li><a href="#">Something else here</a></li>
					<li><a href="#">Separated link</a></li>
				  </ul> -->
				
				  <div class="dropdown">
				<?php if($this->session->userdata['profile_data'][0]['custID'] == $results->custID)
	              
				  {
				  ?>
				   <button class="btn btn-success dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
					Admin
					
				  </button>
				  
				  
				  <?php } else { 
				     
				     
				     foreach($userData as $statusUser);
				      ?>
				    <?php if($countData != 0 && $statusUser->gistatus == 1)
				   {?>
				      <button class="btn btn-success dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
					  Joined
					 <span class="caret"></span>
				  </button>
				  <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
					<li id="<?php echo $statusUser->giID;?>"><a id='LeaveGroup' href="#">Leave group</a></li>

					
				  </ul>
				 <?php }
				       else
					   {
				   ?>
        
				      <a href="#" id="JoinGroupIcon"><button class="btn btn-success" type="button">
					  + Join group
					
				     </button></a>
				
				  
				  <?php } 
				        }
				  ?>
				<!--  <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
					<li><a href="#">Leave group</a></li>

					
				  </ul> -->
			</div>
			</div>
		
		</div>
		
		
	<!--navigations-->		
	</div>
<!--/navigations-->
  </div>
<!--/back class-->  


                 
 
    <div class="col-lg-6 left">
	     <?php if(($this->session->userdata['profile_data'][0]['custID'] == $results->custID) || ($countData != 0 && $statusUser->gistatus == 1))
				   {?>
		<div class="col-md-12 navigations2">
		
			
			<div class="col-md-4">
				<button type="button" class="btn btn-default sty" id="post">Post</button>
			</div>
			
			<div class="col-md-4">
				<button type="button" class="btn btn-default sty" id="events">Events</button>
			</div>
			
			<div class="col-md-4">
				<button type="button" class="btn btn-default sty" id="photos">Photos</button>
			</div>

			
		
		</div> 
		
		<div class="col-md-12 postsection" id="post-hide">
		<div class="well" style="margin-top:15px;"> 
             <form class="form-horizontal" role="form">
              <h4>What's New</h4>
               <div class="form-group" style="padding:14px;">
                <textarea class="form-control" name="postApostBox" id="postApostBox" placeholder="Update your status"></textarea>
              </div>
           
              <input type="submit" class="btn btn-success pull-right" value="Post" style="width:auto;" id="postApost" /> 
			  <ul class="list-inline"><li><a href="#">&nbsp;</a></li></ul> 
            </form>
        </div>
		
		</div>
		
			<div class="col-md-12 postsection" id="event" style="display:none;">
		<div class="well"  style="margin-top:15px;"> 
             <form class="form-horizontal" role="form">
             
               <div class="form-group"  style="padding:5px;">
			   <span class="glyphicon glyphicon-bullhorn"></span> Event Title:
                <input type="text" class="form-control" id="eventTitle" name="eventTitle" placeholder="Event title">
				</div>
				   <div class="form-group"  style="padding:5px;">
               <span class="glyphicon glyphicon-map-marker" /></span> Location:
				  <input type="text" class="form-control" id="eventLocation" name="eventLocation" placeholder="location" > 
              </div> 
			  
			  <div class="form-group"  style="padding:5px;">
                <span class="glyphicon glyphicon-calendar"></span> Event Date: 
			<input type="text" id="eventDate" name="eventDate" placeholder="Event date"  class="form-control eventDate">
              </div>
				 <div class="form-group"  style="padding:5px;">
                <textarea class="form-control" name="eventDes" id="eventDes" placeholder="Tell about event..."></textarea>
              </div>
				
		
           
              <input type="submit" class="btn btn-success pull-right" value="Invite" style="width:auto;" id="postAevent" /> 
			  <ul class="list-inline"><li><a href="#">&nbsp;</a></li></ul> 
            </form>
        </div>
		
		</div>
		
		<div class="col-md-12 postsection" id="photo-hide" style="display:none;">
		<div class="well" style="margin-top:15px;"> 
             <form class="form-horizontal" method="post" enctype="multipart/form-data" action="<?php echo base_url().'groups/doPostwithImage/'.$r;?>" role="form">
              <h4>What's New</h4>
               <div class="form-group" style="padding:14px;">
               <input type="file" name="uploadPhoto" id="uploadPhoto" required>
			   
              </div>
           <div class="form-group" style="padding:14px;">
                <textarea class="form-control" name="postTextinImage" id="postTextinImage" required placeholder="What you want to say..!"></textarea>
              </div>
           
              <input type="submit" class="btn btn-success pull-right" value="Post" style="width:auto;" id="postApostwithImage" /> 
			  <ul class="list-inline"><li><a href="#">&nbsp;</a></li></ul> 
            </form>
        </div>
		
		</div>
		
		<?php } 
		else
		{?>
		<div class="col-md-12 postsection" style="padding-bottom:15px;">
		 <div class="col-md-12 activity" style="padding:20px;margin-top:20px;margin-bottom:0px;">			
			
			
			Join this group to post and comment. 
			
		</div>
		</div>
		<?php } ?>
		<div id="allPosting" class="col-md-12 postsection">
		 
		
		 
		 <?php  
							
							    if(empty($posts))
                                {
								   
								   echo "No posts found...!";
								}
								else
								{
                                 //print_r($posts);
								foreach($posts as $post)
						         {
						     ?>
		
		<div class="singlePost" id="singlePost_<?php echo $post->id;?>" style="background-color:#eee;padding:5px;border:0px dashed yellow;overflow:hidden;">
		<div class="col-md-12 prodetails">
			<div class="col-md-2 proimg">
				<img src="<?php echo base_url().UPLOADS.$post->photo;?>" style="width: 50px;height: 50px;">
			</div>
			<div class="col-md-10 proimg1">
								<?php if($post->custID == $this->session->userdata['profile_data'][0]['custID'] || $this->session->userdata['profile_data'][0]['custID'] == $results->custID){ ?>
			<span class="userAction" id="<?php echo $post->id;?>">
				
			 <p class="userActions pull-right" id="<?php echo $post->id;?>">
							<?php
								switch($post->postType){
									case 1 : $class = 'editData';
											 $data_target = 'exampleModalGroupEdit';
											break;								
									case 2 : $class = 'editDataEvent';
											$data_target = 'editEvent';
											break;
									case 3 : $class = 'editDataPhotoPost';
											$data_target = 'exampleModalEditPhoto';
											break;
								}
							?>
                                  <small><a href="#deleteConfirmation" data-toggle="modal" data-target="#deleteConfirmation" class="deleteConfirmation"><span class="glyphicon glyphicon-remove-circle"></span> Delete</a></small>
                                  <small><a href="#<?php echo $data_target;?>" data-toggle="modal" data-target="#<?php echo $data_target;?>" class="<?php echo $class; ?>"><span class="glyphicon glyphicon-edit"></span> Edit</a></small>
                                </p>
			</span><?php } ?>
				<h5 style="margin-bottom: 0px;line-height: 0;"><?php echo $post->custName;?></h5><br>
				<h6 style="margin-top: 0px;"><?php echo $this->custom_function->get_notification_time($this->config->item('global_datetime'),$post->doDate);?></h6>
			</div>
		</div>
		    <?php if($post->postType ==2) {  ?>
			<div class="col-md-12 imgsection" style="background-image:url(<?php echo base_url('uploads/events/'.rand(1,10).'.jpg');?>);color:#fff;padding:10px;padding-bottom:30px;text-align:center;">
		    <h2 class="postContent"><?php echo $post->eventTitle;?> </h2>
			<span><?php echo $post->postContent;?></span>
		    <h4 class="postContent"><span class="glyphicon glyphicon-time"></span> <?php echo $post->eventDate;?> </h4>
		    <h4 class="postContent"><span class="glyphicon glyphicon-map-marker"></span> <?php echo $post->eventLocation;?> </h4>
			
		</div>
		  <?php } else { ?>
		<div class="col-md-12 imgsection">
			<p class="postContent"><?php echo $post->postContent;?> </p>
		</div> 
		<?php } ?>
		<?php if($post->postType ==3) {  ?>
		<div class="col-md-12 imgsection">
			<img src="<?php echo base_url('uploads/groups/posts').'/'.$post->postImage;?>" style="width: 100%;">
		</div>
		<?php } ?>
		
		
	 
	 <?php if(($this->session->userdata['profile_data'][0]['custID'] == $results->custID) || ($countData != 0 && $statusUser->gistatus == 1))
				   {?>
		
		
		<span style="font-weight:bold;color:green;">(
		<?php 
								 $cat="GROUP";
		
		
		$like_count="SELECT COUNT(`catID`) AS `total_likes` FROM `recentactivity` WHERE `raCategory`='$cat' AND `catID`='".$post->id."' AND `raAction`='LIKE' ";
		$like = $this->db->query($like_count);
		$like_row=$like->result_array();
		
		echo $like_row[0]['total_likes'];  ?>
		
		
		
		
		)</span>
		<?php
								$cat="GROUP";
		
		 $profile_row = $this->session->userdata('profile_data');
		
		$likeed="SELECT * FROM `recentactivity` WHERE `raCategory`='$cat' AND `catID`='".$post->id."' AND `raAction`='LIKE' AND `custID`='".$profile_row['0']['custID']."' ";
		$liked_process = $this->db->query($likeed);
		if($liked_process->num_rows() >= 1){ 
                                 ?>
		
		
				<span class="label label-success">Liked</span>
			
		
		
		<?php }else{  ?>
			
			<span id="user_like<?php echo $post->id; ?>">	<span class="label label-info" onclick="like<?php echo $post->id; ?>()">Like</span></span>
			
			
		<?php } ?>
			
			
			<span class="col-md-9">
			<span class="label label-warning" id="com3">Comments</span>
			<span style="color:blue">( <?php 

								
									$cat="GROUP";
		
		
		$comment_count="SELECT COUNT(`catID`) AS `total_comments` FROM `recentactivity` WHERE `raCategory`='$cat' AND `catID`='".$post->id."' AND `raAction`='COMMENT' ";
		$comment = $this->db->query($comment_count);
		$comment_row=$comment->result_array();


								echo $comment_row[0]['total_comments'];  ?>) </span>
			
			
			
			
				
			
		</span>  
		<h5><b>Comments:</b></h5>
		
		<div class="com" id="comments3" style="padding:1%">
        <?php $select_comment="SELECT * FROM `useraction` ua
		LEFT JOIN `customermaster` cm ON(cm.`custID`=ua.`custID`)
		LEFT JOIN `personalphoto` pp ON(pp.`custID` = cm.`custID`)
		WHERE ua.`uaCategory`='GROUP' AND ua.`catID`='".$post->id."' ORDER BY ua.`uaID` DESC LIMIT 4
		";
		$select_com = $this->db->query($select_comment);
		foreach($select_com->result() as $row)
        {
        ?>
			<div class="display_comm"><img src='/uploads/<?php 
			if(ISSET($row->photo)){
				echo $row->photo;
			}
			else{
				echo "profile.png";
			}
			
			
			?>' height='25px' width='25px' style='margin:2%'><?php echo $row->uaDescription;?></div>

		<?php
		}
		?>
            <p class="d_c"></p>
            <!--------------------------------------------------------------------------------------------------->

            <a href="javascript:void(0)" class="view_more_post_comments" style="color: darkgreen; font-weight: bold">view more comments</a>

            <input type="hidden" id="get_postid" class="get_postid" value="<?php echo $post->id;?>">
            <input type="hidden"  class="increment_number" value="4">
            <!--------------------------------------------------------------------------------------------------->
        </div>
	 <div class="col-md-8 no-padding " style="padding-right:0px"><textarea  id="user_comment<?php echo $post->id; ?>" style="width: 100%;height: 35px;"> </textarea></div>
		 <div class="col-md-4 no-padding" style="padding-left:0px"><button class="btn btn-success" onclick="comment<?php echo $post->id; ?>()" style="width: 46px;height: 34px;font-size:75%;
    padding-top: 0px;
    padding-bottom: 0px;
    padding-left: 0px;
    padding-right: 0px;
    border-radius: 0px;
">submit</button></div>
		<?php } ?>
	   </div>  
	  
	   <script>

function like<?php echo $post->id; ?>(){
	
	var cid="<?php  echo $this->session->userdata['profile_data'][0]['custID'];   ?>";
	var pid="<?php echo $post->custID; ?>";
	var cat="GROUP";
	var act="LIKE";
	var page="recentactivity";
	
	var catid="<?php echo $post->id; ?>";
	$.ajax({
          url: "<?php echo base_url();?>like?cid="+cid+"&& uid="+pid+"&& cat="+cat+"&& act="+act+"&& page="+page+"&catid="+catid
        }).done(function( data ) {
			
			
    $("#user_like<?php echo $post->id; ?>").html("<span class='small fa fa-thumbs-up ' style='color:green'>Liked</span>");
	location.reload();
		  return true;
        }); 
	
}

	</script>
	   
	   
	 <script>
 function comment<?php echo $post->id; ?>() 
 {
	
	var comment_user = $("#user_comment<?php echo $post->id; ?>").val()
	if(comment_user == "")
	{
		$("#user_comment<?php echo $post->id; ?>").focus();
		
	}
	else
	{
	var user_comment = $("#user_comment<?php echo $post->id; ?>").val();
	var uid = "<?php echo $post->custID; ?>";
	var cid = "<?php echo $this->session->userdata['profile_data'][0]['custID'];  ?>";
	var pid="<?php echo $post->id; ?>";
    var cat="GROUP";
	
	var act="COMMENT";
	
      if(user_comment!=''){
        $.ajax({
          url: "<?php echo base_url();?>activity?user_comment="+user_comment+"&uid="+uid+"&cid="+cid+"&pid="+pid+"&cat="+cat+"&act="+act
        }).done(function( data ) {
	location.reload();
	 $("#user_comment<?php echo $post->id;?>").val('');
		  return true;
        });   
      } 
	  
	
    }
 }
  
  </script>
	  
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   <?php 
	      }
         }
   ?>
	   
    </div>
	
	<div id="last_msg_loader" class="item photob_load_more_btn hide col-sm-12">
		<img src="<?php echo base_url().IMAGES;?>ajax-auto-loader.gif" align="absmiddle" alt="Loading..."></img>
    </div>
	
	
    </div>
    <div class="col-lg-6 right">
<!--	
      <div class="col-md-12 serch">
			<div id="custom-search-input">
                <div class="input-group col-md-12">
                    <input type="text" class="form-control input-lg" placeholder="Search...." />
                    <span class="input-group-btn">
                        <button class="btn btn-info btn-lg" type="button">
                            <i class="glyphicon glyphicon-search"></i>
                        </button>
                    </span>
                </div>
            </div>
	  </div>
	  -->
	  <div class="col-md-12 members">
		<h4>Members</h4>
		<?php if($this->session->userdata['profile_data'][0]['custID'] == $results->custID)
	              
				  {
				  ?>
		<div class="form-group">
		  <input type="text" class="form-control" id="mahajyothis_search" name="q">
		</div>
	<span id="sent_information"></span>
		<?php } ?>
		
		<div class="col-md-12" style="border-bottom: 1px solid white;padding-bottom: 4%;padding-left: 0px;">
		
		 <img title="admin" style="width: 50px;height: 50px;" src="<?php echo ($results->photo && file_exists(UPLOADS.$results->photo)) ? base_url().UPLOADS.$results->photo : base_url().UPLOADS.'profile.png';?>" >
		
		 <?php if($Countmembers != 0)
		   {
		      foreach($members as $member)
			  {
			   ?>
			      <img title="<?php echo $member->custName;?>" style="width: 50px;height: 50px;border:1px solid #fff;" src="<?php echo ($member->photo && file_exists(UPLOADS.$member->photo)) ? base_url().UPLOADS.$member->photo : base_url().UPLOADS.'profile.png';?>" >
			  <?php
			  }
			  
		          
		   }
		?>
			<!--<img src="<?php echo base_url('assets/group_rakesh/img/b.jpg');?>" style="width: 50px;">
		
		
			<img src="<?php echo base_url('assets/group_rakesh/img/b.jpg');?>" style="width: 50px;">
		
		
			<img src="<?php echo base_url('assets/group_rakesh/img/b.jpg');?>" style="width: 50px;">
		
		
			<img src="<?php echo base_url('assets/group_rakesh/img/b.jpg');?>" style="width: 50px;">
		
		
			<img src="<?php echo base_url('assets/group_rakesh/img/b.jpg');?>" style="width: 50px;">
		
			<img src="<?php echo base_url('assets/group_rakesh/img/b.jpg');?>" style="width: 50px;">
			-->
		</div>	
		<div class="col-md-12" style="padding-left: 0px;">
		<h5 id="para1_grp"><?=$results->grp_description;?></h5>	
		</div>
	  </div>
	  
	   <div class="col-md-12 members">
	   <a href="<?php echo base_url().'groups';?>" <button type="button" class="btn btn-warning">Create Group</button></a><br /><br />
		<p id="para1">Mahajyothis groups are a great way to share photos, post comments, and hold discussions around a common theme.</p>	
	   
	   </div>
	  
	  
    </div>
  
</div> 

<div class="modal fade" id="exampleModalGroupEdit" tabindex="-1" role="dialog" aria-labelledby="exampleModalGroupEdit">

  <div class="modal-dialog" role="document" style="z-index:9999;">
   <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" id="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="exampleModalLabel">Edit Status</h4>
      </div>
      <div class="modal-body">
      <form method="post" enctype="multipart/form-data">
          <div class="form-group">
            <label for="recipient-name" class="control-label">Post :</label>
            <textarea class="form-control" name="editPostContent" id="editPostContent" required></textarea>
            <p class="required_error hide">* Please fill this field</p>
          </div>
      
      </div>
      <div class="modal-footer">
         <button type="button" class="btn btn-default" data-dismiss="modal" id="editcloseBtn">Close</button>
          <input type="submit" class="btn btn-primary" id="editSavePost" value="Save" />
          <input type="hidden" id="editPostId" value="" />
      </div>
        </form>
    </div>
  </div>
</div>

<div class="modal fade" id="editEvent" tabindex="-1" role="dialog" aria-labelledby="editEvent">

  <div class="modal-dialog" role="document" style="z-index:9999;">
   <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" id="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="exampleModalLabel">Edit Event</h4>
      </div>
      <div class="modal-body">
      <form method="post" enctype="multipart/form-data">
           <div class="form-group"  style="padding:5px;">
			   <span class="glyphicon glyphicon-bullhorn"></span> Event Title:
                <input type="text" class="form-control" id="eventTitleEdit" name="eventTitleEdit" placeholder="Event title">
				</div>
				   <div class="form-group"  style="padding:5px;">
               <span class="glyphicon glyphicon-map-marker" /></span> Location:
				  <input type="text" class="form-control" id="eventLocationEdit" name="eventLocationEdit" placeholder="location" > 
              </div> 
			  
			  <div class="form-group"  style="padding:5px;">
                <span class="glyphicon glyphicon-calendar"></span> Event Date: 
			<input type="text" id="eventDateEdit" name="eventDateEdit" placeholder="Event date"  class="form-control eventDate">
              </div>
				 <div class="form-group"  style="padding:5px;">
                <textarea class="form-control" name="eventDesEdit" id="eventDesEdit" placeholder="Tell about event..."></textarea>
              </div>
      
      </div>
      <div class="modal-footer">
         <button type="button" class="btn btn-default" data-dismiss="modal" id="editcloseBtn">Close</button>
          <input type="submit" class="btn btn-primary" id="eventEditsubmit" value="Save" />
          <input type="hidden" id="eventPostId" value="" />
      </div>
        </form>
    </div>
  </div>
</div>


<div class="modal fade" id="exampleModalEditPhoto" tabindex="-1" role="dialog" aria-labelledby="exampleModalEditPhoto">

  <div class="modal-dialog" role="document" style="z-index:9999;">
   <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" id="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="exampleModalLabel">Edit Status</h4>
      </div>
      <div class="modal-body">
      <form method="post" action="<?php echo base_url().'groups/updatePostwithImage/'.$r;?>" enctype="multipart/form-data">
          <div class="form-group">
            <label for="recipient-name" class="control-label">Post :</label>
            <textarea class="form-control" name="editPhotoContent" id="editPhotoContent" required></textarea>
            <p class="required_error hide">* Please fill this field</p>
          </div>
		  <div class="form-group">
            <label for="message-text" class="control-label">Image:</label>
			<div id="img_container"></div>
            <input type="file" class="form-control" name="editStatusPhoto" id="editStatusPhoto">
			<input type="hidden" id="editStatusPhotoId" name="editStatusPhotoId" value="" />
		 </div>
		  <div class="modal-footer">
			 <button type="button" class="btn btn-default" data-dismiss="modal" id="editcloseBtn">Close</button>
			  <input type="submit" class="btn btn-primary" id="" value="Save" />
			  
		  </div>
        </form>      
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="deleteConfirmation" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog" role="document" style="z-index:9999;">
   <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" id="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="exampleModalLabel"><h2>Delete Confirmation </h2>
      </div>
      <div class="modal-body">
       Do you want to delete this group ?
      </div>
      <div class="modal-footer">
           
    <a href="javascript:void(0)" id="">
      <button type="button" class="btn btn-danger" id="deleteConfirmBtn">Confirm</button>
    </a>
     <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
      </div>
    </div>
  </div>
</div>

               
                     
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
	 
	     <?php include_once('assets/group_rakesh/js/groups.php');?>
		 <script src="<?php echo base_url('assets/dis/js/bootstrap.min.js');?>"></script>
		 <script src="<?php echo base_url('assets/group_rakesh/js/jquery-ui.js');?>"></script>
		 <script src="<?php echo base_url('assets/group_rakesh/js/script.js');?>"></script>
		  <script>var ver172 = $.noConflict();</script>
		 
		  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
		  
		 <script src="<?php echo base_url('assets/js/jquery.autocomplete.js');?>"></script>
		 <script>
			$(document).ready(function (ver172) {
				  ver172("#mahajyothis_search").autocomplete("<?php echo base_url()?>groups/groupmembers", {
						selectFirst: true
				  });
		 });
		</script>

<!--<script>
$(document).ready(function(){
		
	$("#mahajyothis_search").change(function(){
		var name=$(".memberresult").val();
		alert(name)
		$("#mahajyothis_search").val('');
	$(".ac_results").hide();
});
	
});

</script>
<script>
$(document).ready(function(){
		$("#mahajyothis_search").change(function(){
		$("#invitebutton").show();
		$("#sent_information").hide();
		});
	});
</script>-->
<script>
$(document).ready(function(){
		$("#mahajyothis_search").change(function(){
			
			setTimeout(function(){
			
			
	var name=$("#mahajyothis_search").val();
	if(name!='No User Found' & name.length >3){
	var groupID=<?php echo $this->session->userdata['groupID']; ?>;
	if(name!=''){
		$.ajax({
          url: "<?php echo base_url();?>groups/invitations?name="+name+"&gid="+groupID
        }).done(function( data ) {
		$("#invitebutton").hide();
		$("#mahajyothis_search").val('');
		$("#sent_information").html("<font color='navy'>"+name+" </font><font color='green'>has been added...</font>").show();
		  return true;
        }); 
		}
	if(name==''){
		$("#mahajyothis_search").focus();	
	return false;
	}}
	}, 100 );
});
	});

</script>
		 <script>
	$(document).ready(function(){
	$("#post").click(function(){
        $("#post-hide").fadeIn();
		$("#event").hide();
		 $("#photo-hide").hide();
    });
    $("#events").click(function(){
        $("#event").fadeIn();
		$("#post-hide").hide();
		 $("#photo-hide").hide();
    });
	$("#photos").click(function(){
	     $("#photo-hide").fadeIn();
        $("#event").hide();
		$("#post-hide").hide();
	
    });
    
})
	</script>
		 

    <script>


        $(document).ready(function()
        {
            $(".view_more_post_comments").click(function()

            {
                var curr = $(this);
                var postid = $(this).siblings('input.get_postid').val();
                var limits = "limits";

                var inc = $(this).siblings("input.increment_number").val();
                $.ajax
                ({
                    url: "<?php echo base_url();?>Groups/view_more_comments_based_on_status?limits="+limits+"&& postid="+postid+"&& inc="+inc
                }).done(function( data ) {



                    curr.siblings('.display_comm').hide()
                    curr.siblings('.d_c').html(data)


                   //alert(data);


                });


            });
        });
    </script>

    <script>
        $(document).ready(function(){
            $(".view_more_post_comments").click(function(){
                var $n = $(this).siblings(".increment_number");
                $n.val(Number($n.val())+4);
            });
        });
    </script>
	<div class="col-md-12 footer1">		 
			<h5>Mahajyothis &copy; 2015</h5>
		 </div>
	</body>
</html>