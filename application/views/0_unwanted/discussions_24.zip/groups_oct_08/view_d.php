<!doctype html>
<html lang="en">
    <head>       
        <meta charset="utf-8" />
        <title><?php echo $results->grp_name;?></title>
        
        <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1, maximum-scale=1, user-scalable=no">

        <!--[if lt IE 9]><script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->

        <link href='http://fonts.googleapis.com/css?family=Open+Sans:300,600' rel='stylesheet' type='text/css'>


		 
		  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
		  
		 <script src="<?php echo base_url('assets/js/jquery.autocomplete.js');?>"></script>
		 <script>
			$(document).ready(function (ver172) {
				  ver172("#mahajyothis_search").autocomplete("<?php echo base_url()?>groups/groupmembers", {
						selectFirst: true
				  });
		 });
		</script>
          <script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
		  
         <script src="<?php echo base_url('assets/grouppage/group-page-innr/js/jquery.isotope.min.js');?>" type="text/javascript"></script> <!-- jQuery Library -->
		 
         <script src="<?php echo base_url('assets/grouppage/group-page-innr/js/jquery.mousewheel.js');?>" type="text/javascript"></script> <!-- jQuery Library -->
		 
         <script src="<?php echo base_url('assets/grouppage/group-page-innr/js/tileshow.js');?>" type="text/javascript"></script> <!-- jQuery Library -->
		 
		 
         <script src="<?php echo base_url('assets/grouppage/group-page-innr/js/script.js');?>" type="text/javascript"></script> <!-- jQuery Library -->
         
		 <script src="<?php echo base_url('assets/grouppage/group-page-innr/js/overlay.js');?>" type="text/javascript"></script> <!-- jQuery Library -->
         
		  <script src="<?php echo base_url('assets/grouppage/group-page-innr/js/jquery.mCustomScrollbar.js');?>" type="text/javascript"></script>
		  
		 
		 
		 <script src="<?php echo base_url('assets/grouppage/group-page-innr/js/bootstrap.min.js');?>" type="text/javascript"></script>
  
        <link href="<?php echo base_url('assets/grouppage/css/overlay.css');?>" rel="stylesheet">
		<link href="<?php echo base_url('assets/grouppage/css/style.css');?>" rel="stylesheet">
		<link href="<?php echo base_url('assets/grouppage/css/style-groups.css');?>" rel="stylesheet">
        <link href="<?php echo base_url('assets/grouppage/css/bootstrap-cols.css');?>" rel="stylesheet">
        <link href="<?php echo base_url('assets/grouppage/group-page-innr/css/style-grp-in.css');?>" rel="stylesheet">
		<link href="<?php echo base_url('assets/group_rakesh/css/jquery-ui.css');?>" rel="stylesheet">
		
		<link href="<?php echo base_url('assets/grouppage/facy-box/fancy.css');?>" rel="stylesheet">
		 <script src="<?php echo base_url('assets/grouppage/facy-box/fancy_box.js');?>" type="text/javascript"></script>

       <style>
       .psts-lft-scrl .mCSB_container{ top:0 !important}
	   .ac_results li{
		   z-index:9999;
		   color:white;
		 background-color: #DA4F49;
		 padding:3%;
		 width:100%
	   }
	   .ac_results li:hover{ cursor:pointer}
	   .ac_results{    z-index: 999999;
    width: 361px !important;}
	.mCSB_horizontal > .mCSB_container{ margin-top: -80px;/* margin-left: -93px; */}
	   .form-dark textarea, .form-dark input[type="text"], .form-dark input[type="password"], .form-dark input[type="datetime"], .form-dark input[type="datetime-local"], .form-dark input[type="date"], .form-dark input[type="month"], .form-dark input[type="time"], .form-dark input[type="week"], .form-dark input[type="number"], .form-dark input[type="email"], .form-dark input[type="url"], .form-dark input[type="search"], .form-dark input[type="tel"], .form-dark input[type="color"], .form-dark .uneditable-input{background: rgba(8, 1, 1, 0.32) none repeat scroll 0% 0%;}
	   .pf-img-pst{
	   	width: 35px;
    		height: 35px;
    		border-radius: 50px;
	   }
	   .cmnt-area-bottm{
	   	
   		 background: rgba(24, 64, 53, 0.69);
   		 padding: 8%;
   		
	   }
	   </style>
    </head>
	
    <body>
	    
		<!--  DATA WE NEEDED -->
		 <?php 
                    $countData = count($userData);
                    $Countmembers =  count($members);
                    $CountRequests =  count($userJoinRequests);
           ?>

        <div class="header">
           <div class="icn-bck-clsss">
										<a href="<?php echo base_url('groups'); ?>"><img src="<?=base_url("assets/grouppage/img/back-arrw.png");?>" style="margin-top: 4px;"></a>
									<span style="font-size: 28px;padding: 12px;vertical-align: top;"><?php echo $results->grp_name; ?></span>
    
	<?php
	if($this->session->userdata['profile_data'][0]['custID'] == $results->custID && $CountRequests != 0)
									{ ?>
	<a data-overlay-trigger="userRequestInfo" href="#!" style="position: fixed;
left: 87%;top:2%;"><span class="rht-tp-icn_2" style="font-size:15px;"> <i class="fa fa-bell"></i> <span id="RequestsCountOrginal"><?php echo $CountRequests;?></span></span>
	</a>
	
		
	
	<?php } ?>
	<?php
	if($this->session->userdata['profile_data'][0]['custID'] == $results->custID)
									{ ?>
	<a data-overlay-trigger="UsersManagement" href="#!" style="position: fixed;
left: 90%;top:2%;"> <span class="rht-tp-icn_2" style="font-size:15px;"> <i class="fa fa-users"></i> <span id="MembersCountOrginal"><?php echo $Countmembers;?></span></span>
	</a>
	<?php } ?>
	

								</div>
        </div>
        <!-- /LOGO -->

        <!-- MAIN CONTENT SECTION -->
		
        <section id="content">
        
            
            <section class="clearfix section" id="about">
           
                <!-- SECTION TITLE -->
				
                <h3 class="block-title"></h3>
                <!-- /SECTION TITLE -->

                <!-- SECTION TILES -->
             

                <div class="tile black htmltile w3 h4" style="width: 350px !important;">
                    <div class="tilecontent">
					
                        <div class="content">
						
						<div class="thumbnail prfl-img-cls" >
								<img src="<?=base_url()."uploads/groups/banners/".$results->grp_cover;?>" class="pf-img" alt="User Profile" />
								
										<div class="joind-clsss">
											  <?php if($this->session->userdata['profile_data'][0]['custID'] == $results->custID)
	              
				                               {
				                                 ?>
				   
					                           
											   <span class="slct-bck-clr">
												Admin
											   </span>
				 
				  
				  
				  <?php }  else
				        {
					
				        foreach($userData as $statusUser);
				        ?>
				    <?php if($countData != 0 && $statusUser->gistatus == 1)
				   {?>
				     

	                                      <p class="slct-bck-clr" id="<?php echo $statusUser->giID; ?>" style="text-align:center;padding-top:5px;">
											
											<a href="#" class='LeaveGroup'>Leave group</a>
											</p>
						
				 <?php }
				       else if($countData != 0 && $statusUser->gistatus == 3)
					   {
				   ?>
        
		  <p class="slct-bck-clr" style="text-align:center;padding-top:5px;" id="<?php echo $statusUser->giID; ?>">
				      
					  
					  <i class="fa fa-exclamation-circle"></i> Pending <small>|</small> <a href="#" class='LeaveGroup'>Cancel</a>
					
				   
				
				  </p>
				  <?php } 
				  else
					   {
				   ?>
        
		  <p class="slct-bck-clr" style="text-align:center;padding-top:5px;">
				      <a href="#"  id="JoinGroupIcon">
					  
					  + Join group
					
				     </a>
				
				  </p>
				  <?php }
				        }
				  ?>
											  
											  
										</div>	
								
						</div>
                  </div>
				  
				  <div class="detls-sec-grp">
				  
                           <p style="padding-right:23px;font-size:12px;line-height:18px;padding-left:20px;padding-top: 3px;">
										<?php echo $results->grp_description; ?>
										
										 
									</p>
									
						</div>
						<div class="col-md-12 group_section" style="background-color:#081c1a;padding-top:10px;padding-bottom:-2px;margin-top: -3px;">
									
									    <div class="col-md-4 "><i class="fa fa-user "></i>
										<p style="padding-left:19px;margin-top: -14px;color: #40a293;">Admin <span style="font-style:italic;"><?php echo ucwords($results->custName); ?></span> </p>
										</div>
										<div class="col-md-4 "><i class="fa fa-clock-o"></i>
										<p style="padding-left:19px;margin-top: -14px;color: #40a293;"><?php echo date('M y',strtotime($results->doDate));?></p>
										</div>
									
									</div>
                <div class="members-lst-cls">
								<div class="membrs-count">
									<p style=" color: #fff;padding-left: 18px;margin-top:2px;padding-bottom: 11px;">(<?php echo $Countmembers+1;?>) Members</p>
							<?php		if($this->session->userdata['profile_data'][0]['custID'] == $results->custID)
									{ ?>
											<div class="input-grps" style="padding-bottom:3px;margin-top: -6px;">
												  <span class="input-grps-icnn" id="sizing-addon1" style="  padding-bottom: 15px;padding-top: 14px;background: rgba(18, 15, 15, 0.33) none repeat scroll 0% 0%;color:#359587;">+</span>
												  <input type="text" class="input-grps-rght" id="mahajyothis_search" placeholder="Add Members" style="padding-bottom: 1px;padding-top: 5px;  background: rgba(18, 15, 15, 0.33) none repeat scroll 0% 0%;border:none;  padding-bottom: 10px;padding-top: 10px;">
											</div>
											<div id="sent_information" style='text-align:center;'></div>
									<?php } ?>
											
	
	
								</div>
							</div>
						</div>
						
                       
						
                    </div>
					
                </div>
				
                <!-- /SECTION TILES -->
          
            </section>
			
			
			
			
			
            <?php if(($this->session->userdata['profile_data'][0]['custID'] == $results->custID) || ($countData != 0 && $statusUser->gistatus == 1))
				   {?>
          <section class="clearfix section">

                <!-- SECTION TITLE -->
                <h3 class="block-title" style="margin-top:26px; !important">Update what you like now?</h3>
                <!-- /SECTION TITLE -->

                <!-- SECTION TILES -->
                <div class="tile black htmltile w3 h4 psts-lft-scrl" style="margin-top:35px; !important; ">
                    <div class="tilecontent">
                        <div class="content">

						
						<ul class="listmnu">
							<li id="pst-dsply-mnu" style="background-color:#688781;">Posts</li>
							<li id="pst-even-mnu" style="background-color:#1f3e36;">Events</li>
							<li id="pst-img-mnu">Add Photo</li>
							
						</ul>
						
						<div class="comment-area" style="transition:all 1s ease-in-out;">
							<div id="pst-dsply-blck">
							 <form class="form-horizontal" role="form">
							<textarea class="commnt-txtara" name="postApostBox" id="postApostBox" placeholder="Update your status"></textarea>
							
									<div class="submit-btnn-cls" style="">
									<input type="submit" value="Post" id="postApost" class="btn btn-danger submt-btn" style="background-color: #359587;">
									</div>
									</form>
							</div>			 
								</div>													
		
								<div id="event-frmm" style="background: rgba(32, 30, 30, 0.6) none repeat scroll 0% 0%;padding: 5%;">
								
							
								
								
                            <form id="contactme" class="form-dark" name="">
                                <div class="row-fluid"  style="margin-top:15px;">
                                    <label>Event Title </label>
                                    <input type="text" class="span12" id="eventTitle" name="eventTitle" placeholder="Event title">
                                </div>
								
								<div class="row-fluid"  >
                                    <label>Location</label>
                                   
									<input type="text" class="span12" id="eventLocation" name="eventLocation" placeholder="Event location" /> 
                                </div>
                               
							   <div class="row-fluid"  >
                                    <label>Event date</label>
                                   
									<input type="text" class="span12 eventDate" id="eventDate" name="eventDate" placeholder="Event date" placeholder="Event date" /> 
                                </div>
							   
							   
							   <div class="row-fluid"  >
                                    <label>Event description</label>
                                    <textarea class="span12" name="eventDes" id="eventDes" placeholder="Tell about event..."></textarea>
                                </div>
                                <div class="row-fluid">
                                    <input type="submit"  value='Create' id="postAevent" class="btn btn-danger submt-btn" style="background-color: #359587;"/>
                                </div>
                            </form>
							</div>
							<div id="add-pst-vide">
							 <form class="form-horizontal" method="post" enctype="multipart/form-data" action="<?php echo base_url().'groups/doPostwithImage/'.$r;?>" role="form">
							   
							    <div class="row-fluid">
								  <label>Upload photo</label>
								    <div id="img_container" style='padding:3px;display:none;'></div>
							   <input type="file" class="span12" name="uploadPhoto" id="uploadPhoto" accept='image/*' required>
									  
									</div>  
									  <div class="row-fluid">
							 
							 <textarea class="commnt-txtara" name="postTextinImage" id="postTextinImage" required placeholder="What you want to say..!" style="width: 92%;margin-left:5px"></textarea>
							</div>
							
							
							
                                    
                                    <input type="submit"  value='Post' class="btn btn-danger submt-btn" />
									
									</form>
                                
							</div>
						
					
				
			
				<?php if(empty($posts))
                                {
								   ?>
								   	<div class="nopostfound">
									<?php
								   echo "No posts found...!</div>";
								   
								
								}
								
								?>
								</div>


							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
						</div>
		                  
                        </div>
						
                    </div>
                </div>
                <!-- /SECTION TILES -->

            </section>
			<?php } ?>
			              
						  
						  
					     <?php  
							
							    if(empty($posts))
                                {
								   
								   echo "";
								}
								else
								{
                                 //print_r($posts);
								$i = 0;
								
								$header_content = "<section class='clearfix section' id='contactform'><div class='tile black htmltile w3 h4'><div class='tilecontent'><div class='content'>";
								 $footer_content = "</div></div></div>
                                     </section>";
								foreach($posts as $post)
						         {
								    
									
									if($i == 2 || $i == 0 )
									 {
									     echo $header_content;
										 $i = 0;
									 }
								 
								 
								
								
						     ?>
							 <div class="pst-cntnts " style="height:100%;  background-color: #0c231d;" id="singlePost_<?php echo $post->id;?>">
							<div class="group_text" style="background-color:#0f372f; height: 72px;margin-top:10px;">
							<div class="img-cntnr thumbnail"   style="margin-top: 10px;">
							
								<img src="<?php echo base_url().UPLOADS.$post->photo;?>" class="img-circle" alt="User Profile" width="50" height="50">
						</div>
							<div class="usr-pfle-nme">
							<div class="pst-nmes-clss" style="margin-top: 7px;">
								<h3 style="font-size: 15px !important;"><?php echo $post->custName;?></h3>
								<p><?php echo $this->custom_function->get_notification_time($this->config->item('global_datetime'),$post->doDate);?></p>
							</div>
						
							<?php if($post->custID == $this->session->userdata['profile_data'][0]['custID'] || $this->session->userdata['profile_data'][0]['custID'] == $results->custID){ ?>
			
							<div class="userActions pst-editdel-clss" id="<?php echo $post->id;?>">
							
							<?php
								switch($post->postType){
									case 1 : $class = 'editData';
											 $data_target = 'editStatusInGroupsInner';
											break;								
									case 2 : $class = 'editDataEvent';
											$data_target = 'editEventSection';
											break;
									case 3 : $class = 'editDataPhotoPost';
											$data_target = 'editStatusWithPhoto';
											break;
								}
							?>
							
							
								<a data-overlay-trigger="<?php echo $data_target;?>" class="<?php echo $class;?>" href="#!"><span class="icn-spce-grp"><i class="fa fa-pencil-square-o" style="color:#fff"></i></span></a>
								
								<a href='#' class="Del_post" data-overlay-trigger="forDelete"><span  class="icn-spce-grp"><i class="fa fa-trash-o" style="color:#fff"></i></span></a>
							</div>
							<?php } ?>
							
							
							
							
														</div>
														</div>
														
													
                               	<?php if($post->postType ==2) {  ?>
			                <div class="col-md-12" style="background-image:url(<?php echo base_url('uploads/events/'.rand(1,10).'.jpg');?>);color:#fff;padding:10px;padding-bottom:30px;text-align:center;">
		                          <h2 class="PostedEventtitle"><?php echo $post->eventTitle;?> </h2>
			                      <p class="PostedEventContent" style="padding:4px"><?php echo $post->postContent;?></p>
		                          <h3 class="PostedEventDate"><i class="fa fa-calendar-times-o"></i> <?php echo $post->eventDate;?> </h3>
		                          <h4 class="PostedEventLocation" style="font-size:14px"><i class="fa fa-map-marker"></i> <?php echo $post->eventLocation;?> </h4>
			                     </div>
		  <?php } 
		   if($post->postType == 1) { ?>
		     <div class="col-md-11">
			  <p class="postContent" style="clear: both;"><?php echo $post->postContent;?> </p>
		</div> 
		<?php } ?>
						  
                           <?php if($post->postType ==3) {  ?>
						    <p style="padding: 10px;clear: both;" class="postContent">
							<?php echo $post->postContent;?>
							</p>
		   <div class="pstdd-img thumbnail" style="border: none;
padding: 0.111%;overflow: hidden;max-height: 305px;">
			<a href="#facyme_<?php echo $post->id;?>" class="fancybox"><img src="<?php echo base_url('uploads/groups/posts').'/'.$post->postImage;?>" class="img-responsive" style="width: 100%;" /></a>
		</div>
		
		  <div id="facyme_<?php echo $post->id;?>" style="display:none">
                                     <img src="<?php echo base_url('uploads/groups/fancy_show').'/'.$post->postImage;?>">
                            </div>
		<?php } ?>													
														
														
														
						   <div class="row" style="margin:0 auto">
								 
                           		<div class="col-md-12 " style="background: rgba(8, 28, 26, 0.92) none repeat scroll 0% 0%;margin: 0px auto;margin-bottom:14%">
									<div class="lke-cmnt" style="margin-left: 38%;padding: 8px;margin-bottom: 0px;">
								
								
							 (<span id="user_likes<?php echo $post->id; ?>">
            <?php 
                 $cat="Group";
    
    
    $like_count="SELECT COUNT(`catID`) AS `total_likes` FROM `recentactivity` WHERE `raCategory`='$cat' AND `catID`='".$post->id."' AND `raAction`='LIKE' ";
    $like = $this->db->query($like_count);
    $like_row=$like->result_array();
    
    echo $like_row[0]['total_likes'];  ?> </span>)
 <?php
                $cat="GROUP";
    
     $profile_row = $this->session->userdata('profile_data');
    
    $likeed="SELECT * FROM `recentactivity` WHERE `raCategory`='$cat' AND `catID`='".$post->id."' AND `raAction`='LIKE' AND `custID`='".$profile_row['0']['custID']."' ";
    $liked_process = $this->db->query($likeed);
    if($liked_process->num_rows() >= 1){ 
                                 ?>
                 <span class="small" style="padding:3px;border-radius:3px;" ><span class="small fa fa-thumbs-up" style="color:green;"></span> </span> 
                 
                 
    <?php }else{ ?>
                 <span class="small" style="padding:3px;border-radius:3px;" id="user_like<?php echo $post->id; ?>"  onclick="user_like<?php echo $post->id;?>()"><span class="small fa fa-thumbs-o-up"></span> </span>
                  

    <?php  } ?> 

  (<span id="recent_comment_count<?php echo $post->id;?>">
              
              <?php

                
                  $cat="GROUP";
    
    
    $comment_count="SELECT COUNT(`catID`) AS `total_comments` FROM `recentactivity` WHERE `raCategory`='$cat' AND `catID`='".$post->id."' AND `raAction`='COMMENT' ";
    $comment = $this->db->query($comment_count);
    $comment_row=$comment->result_array();


                echo $comment_row[0]['total_comments'];  ?> </span>)
              
	<span class="pst-cmntss" id="cmnt-boxx_<?php echo $post->id;?>" style="cursor: pointer;"><i class="fa fa-comment" style="padding-right:5px;"></i>comment</span>
						  </div>
						  </div>
						  </div>
						  <div class="com" id="comments3" style="margin-top: -32px;">
						  <div class="coment_display">
	
						    <div id="recent_comment<?php echo $post->id;?>">
          <?php $select_comment="SELECT * FROM `useraction` ua 
    LEFT JOIN `customermaster` cm ON(cm.`custID`=ua.`custID`)
    LEFT JOIN `personalphoto` pp ON(pp.`custID` = cm.`custID`)
    WHERE ua.`uaCategory`='GROUP' AND ua.`catID`='".$post->id."' ORDER BY ua.`uaID` DESC LIMIT 4
    ";
    $select_com = $this->db->query($select_comment);
    foreach($select_com->result() as $row)
        {
            ?>
          
          <div class="cmnt-area-bottm">
            <div class="thumbnail" style="float:left; border:none; padding:0">
              <img src="/uploads/<?php if(ISSET($row->photo)){echo $row->photo;}else{ echo "profile.png";}?>" class="pf-img-pst" alt="User Profile"/>
            </div>
            <span style='    margin-left: 3%;'><?php echo $row->uaDescription; ?></span>
          </div>
          
    <?php  } ?>
          
          </div>
            <p class="d_c" style=" margin-top: 38px"></p>
           

            <input type="hidden" id="get_postid" class="get_postid" value="215">
            <input type="hidden" class="increment_number" value="4">
          
        </div>
						  
						  <div id="cmnt-area_<?php echo $post->id;?>" style="display:none;">
						  
						  <textarea id="user_comment<?php echo $post->id;?>" placeholder="Comment Here . . ." style="width:95%; background:transparent"></textarea>
              <input type="button" class="btn btn-danger pull-right" style="background-color: rgb(45, 106, 88);margin-bottom: 3%;width: 100px;height: 38px;margin-top:4%;" onclick="submit_comment<?php echo $post->id;?>()" value="Submit">
						  </div>
						  
						  
	
	</div>
	
	  
	   	 

						 
</div>

<script>

function user_like<?php echo $post->id;?>(){
  
  var cid="<?php  echo $this->session->userdata['profile_data'][0]['custID'];   ?>";
  var pid="<?php echo $post->custID; ?>";
  var cat="GROUP";
  var act="LIKE";
  var page="recentactivity";
  var catid="<?php echo $post->id; ?>";
  $.ajax({
          url: "<?php echo base_url();?>like?cid="+cid+"&& uid="+pid+"&& cat="+cat+"&& act="+act+"&& page="+page+"&catid="+catid
        }).done(function( data ) {
      
       
    $("#user_like<?php echo $post->id; ?>").html("<span class='small fa fa-thumbs-up ' style='color:green'></span>");
  $("#user_likes<?php echo $post->id; ?>").load('<?php echo base_url(); ?>groups/recent_like_count?id_post='+catid);
      return true;
        }); 
  
}

  </script> 
        
  <script>
 function submit_comment<?php echo $post->id; ?>() 
 {
  
  var comment_user = $("#user_comment<?php echo $post->id; ?>").val();

  if(comment_user == "")
  {
    $("#user_comment<?php echo $post->id; ?>").focus();
    
  }
  else
  {
  var user_comment = $("#user_comment<?php echo $post->id; ?>").val();
  var uid = "<?php echo $post->custID; ?>";
  var cid = "<?php echo $this->session->userdata['profile_data'][0]['custID'];  ?>";
  var pid="<?php echo $post->id; ?>";
    var cat="GROUP";
 
  var act="COMMENT";
  
      if(user_comment!=''){
        $.ajax({
          url: "<?php echo base_url();?>activity?user_comment="+user_comment+"&uid="+uid+"&cid="+cid+"&pid="+pid+"&cat="+cat+"&act="+act
        }).done(function( data ) {
  
   
      return true;
        });   
        $.ajax({
          url: "<?php echo base_url();?>groups/recent_comments"
        }).done(function( data ) {
       
   $("#recent_comment<?php echo $post->id;?>").load('<?php echo base_url(); ?>groups/recent_comments?id_post='+pid);
   $("#user_comment<?php echo $post->id;?>").val('');
      return true;
        });  
      $.ajax({
          url: "<?php echo base_url();?>groups/recent_comment_count"
        }).done(function( data ) {
  
  $("#recent_comment_count<?php echo $post->id;?>").load('<?php echo base_url(); ?>groups/recent_comment_count?id_post='+pid);
      return true;
        });  
        
        
        
        
        
        
      } 
    
  
    }
 }
  
  </script>

<script>
						  $(document).ready(function() {
						  $('#cmnt-boxx_<?php echo $post->id;?>').css('cursor','pointer');
                          $('#cmnt-boxx_<?php echo $post->id;?>').click(function() {
                          $('#cmnt-area_<?php echo $post->id;?>').slideToggle();
                               });
                             });
	</script>
							 
							 
					



<?php $i++; 

if($i == 2)
									 {
									     echo $footer_content;
										
									 }
} }?>
                        
                     

					
        </section> 
   

	<div class="overlay" id="userRequestInfo">
      <div class="modal1" style="width: 40%;height:30%;padding: 1%;box-shadow: 0px 4px 15px 2px rgba(19, 21, 24, 0.4);">
	<div class="simp-cls" style="position:absolute;top:0">  <a href="#!"  onclick="$('.overlay#userRequestInfo').trigger('hide');return false;" >x</a></div>
         
               
					 <h3 class="block-title" style="margin-top: 15px;
margin-left: 9px;">Group Join Requests</h3>
                            
							 <?php 
							 if($CountRequests != 0)
							 {
							//print_r($userJoinRequests);
							 foreach($userJoinRequests as $request)
							 {
							  /*$custID =  $request->custID;
							 
							  $query = $this->db->query('
			                  SELECT cm.custID,cm.custName,pp.photo FROM `customermaster` cm LEFT JOIN `personalphoto` pp ON(pp.`custID` = cm.`custID`) WHERE cm.custID = '.$custID.'
			                    ');
	                     
							 $requestedUser = $query->result();
							 */
							
							     ?>
								 
								 <div class="col-md-12 requestBlock_<?php echo $request->giID;?>" style="padding:5px;" id="<?php echo $request->giID;?>">
							     <div class="col-md-2">
							     <img src="<?php echo base_url('uploads').'/'.$request->photo;?>" style="height:60px;width:60px;padding:5px;" class="pf-img-pst" alt="User Profile">
							     </div>
							     <div class="col-md-4" style="padding-top:20px;padding-bottom:10px;">
							     <p><?php  echo $request->custName;?> want to join in this group..</p>
							     </div>
							     <div class="col-md-3" id="<?php echo $request->giID;?>">
							     <input type="submit" value="Accept" class="btn btn-success acceptJoinRequest" />
								&nbsp;
								  <input type="submit" value="Cancel" class="btn btn-danger cancleJoinRequest" />
							     </div>
							   
							     </div>
								 
								 <div class="col-md-12" style="padding:5px;text-align:center;color:red;display:none;" id="noMoreRequests">No more Requests found...!</div>
								 
							<?php
							 }
							 }
							 else
							 {
							 ?>
							      <div class="col-md-12" style="padding:5px;text-align:center;">No more Requests found...!</div>
							 <?php 
							 }
						
							?>
							
                       
                   
                <!-- /SECTION TILES -->

      
      </div>
    </div>
	
	<div class="overlay" id="UsersManagement">
      <div class="modal1" style="width: 40%;height:30%;padding: 1%;box-shadow: 0px 4px 15px 2px rgba(19, 21, 24, 0.4);">
	<div class="simp-cls" style="position:absolute;top:0">  <a href="#!"  onclick="$('.overlay#UsersManagement').trigger('hide');return false;" >x</a></div>
         

                
					 <h3 class="block-title" style="margin-top: 15px;
margin-left: 9px;">Group Members</h3>
                            
							 <?php 
							 if($Countmembers != 0)
							 {
							 foreach($members as $request)
							 {
							     ?>
								 
								 <div class="col-md-12 removeMemberBlock_<?php echo $request->giID;?>" style="padding:5px;" id="<?php echo $request->giID;?>">
							     <div class="col-md-2">
							     <img src="<?php echo base_url('uploads').'/'.$request->photo;?>" style="height:60px;width:60px;padding:5px;" class="pf-img-pst" alt="User Profile">
							     </div>
							     <div class="col-md-4" style="padding-top:20px;padding-bottom:10px;">
							     <p><?php  echo $request->custName;?></p>
							     </div>
							     <div class="col-md-3" id="<?php echo $request->giID;?>">
								  <input type="submit" value="Remove member" class="btn btn-danger RemovememberFromGroup" />
							     </div>
							     </div>
								 <div class="col-md-12" style="padding:5px;text-align:center;color:red;display:none;" id="noMoremembersFound">No more members found...!</div>
								 
							<?php
							 }
							 }
							 else
							 {
							 ?>
							      <div class="col-md-12" style="padding:5px;text-align:center;">No more members found...!</div>
							 <?php 
							 }
						
							?>
							
                       
                    
                <!-- /SECTION TILES -->

      
      </div>
    </div>
	
	
	<div class="overlay" id="editStatusInGroupsInner">
      <div class="modal1" style=" width: 30%;height:25%;padding: 1%;box-shadow: 0px 4px 15px 2px rgba(19, 21, 24, 0.4);">
	<div class="simp-cls" style="position:absolute;top:0">  <a href="#!"  onclick="$('.overlay#editStatusInGroupsInner').trigger('hide');return false;" >x</a></div>
         

                <!-- SECTION TITLE -->
               
                <!-- /SECTION TITLE -->

                <!-- SECTION TILES -->
               
					 <h3 class="block-title" style="margin-top: 15px;
margin-left: 9px;">Edit Status</h3>
                            <form id="contactme" class="form-dark" name="cform" method="post" action="">
                               
								<div class="row-fluid"  >
                                   
                                    <textarea class="span12" name="editPostContent" id="editPostContent"></textarea>
                                </div>
                            
                                <div class="row-fluid">
								    
                                   
								   <button onclick="$('.overlay#editStatusInGroupsInner').trigger('hide');return false;" id="CloseMeatEDIT" class="btn btn-danger submt-btn">Close</button>
								   
								   <button type="submit" id="editSavePost" class="btn btn-success submt-btn">Update</button>
									 <input type="hidden" id="editPostId" value="" />
                                </div>
                            </form>
                       
                    </div>
                </div>
                <!-- /SECTION TILES -->

    
	
	
	

               
              
	<div class="overlay" id="editStatusWithPhoto">
      <div class="modal1" style="width: 28%;height:55%;padding: 1%;box-shadow: 0px 4px 15px 2px rgba(19, 21, 24, 0.4);">
	<div class="simp-cls" style="position:absolute;top:0">  <a href="#!"  onclick="$('.overlay#editStatusWithPhoto').trigger('hide');return false;" >x</a></div>
         

                <!-- SECTION TITLE -->
               
                <!-- /SECTION TITLE -->

                <!-- SECTION TILES -->
                
					 <h3 class="block-title" style="margin-top: -7px;margin-left: 9px;margin-bottom: 19px;">Edit Status with Photo</h3>
                           <form method="post" class="form-dark" action="<?php echo base_url().'groups/updatePostwithImage/'.$r;?>" enctype="multipart/form-data">
                               
								<div class="row-fluid">
                                    
                                    <textarea class="span12" name="editPhotoContent" id="editPhotoContent"></textarea>
                                </div>
								<div class="row-fluid">
                            <div id="img_container1"></div>
							 <label>Change Image </label>
                             
							 <input type="file" class="form-control" name="editStatusPhoto" id="editStatusPhoto">
			                 <input type="hidden" id="editStatusPhotoId" name="editStatusPhotoId" value="" />
							
							</div>
							
                                <div class="row-fluid">
								    
                                   
								   <button onclick="$('.overlay#editStatusWithPhoto').trigger('hide');return false;" id="CloseMeatEDIT" class="btn btn-danger submt-btn">Close</button>
								   
								   <input type="submit" value="Update" class="btn btn-success submt-btn" />
									 <input type="hidden" id="editPostId" value="" />
                                </div>
                            </form>
                       
                    </div>
                </div>
                <!-- /SECTION TILES -->

	
	
	
	
	
	
		<div class="overlay" id="editEventSection">
      <div class="modal1" style="width: 30%;height:55%;padding: 1%;box-shadow: 0px 4px 15px 2px rgba(19, 21, 24, 0.4);">
	<div class="simp-cls" style="position:absolute;top:0">  <a href="#!"  onclick="$('.overlay#editEventSection').trigger('hide');return false;" >x</a></div>
         

                <!-- SECTION TITLE -->
               
                <!-- /SECTION TITLE -->

                <!-- SECTION TILES -->
                
					 <h3 class="block-title" style="margin-top: 15px;
margin-left: 9px;">Edit Event</h3>
                            <form id="contactme" class="form-dark" name="cform" method="post" action="">
                               
								 <div class="row-fluid"  style="margin-top:15px;">
                                    <label>Event Title </label>
                                    <input type="text" class="span12" id="eventTitleEdit" name="eventTitleEdit" placeholder="Event title">
                                </div>
								
								<div class="row-fluid"  >
                                    <label>Location</label>
                                   
									<input type="text" class="span12" id="eventLocationEdit" name="eventLocationEdit" placeholder="Event location" /> 
                                </div>
                               
							   <div class="row-fluid"  >
                                    <label>Event date</label>
                                   
									<input type="text" class="span12 eventDate" id="eventDateEdit" name="eventDateEdit" placeholder="Event date" placeholder="Event date" /> 
                                </div>
							   
							   
							   <div class="row-fluid"  >
                                    <label>Event description</label>
                                    <textarea class="span12" name="eventDesEdit" id="eventDesEdit" placeholder="Tell about event..."></textarea>
                                </div>
                            
                                <div class="row-fluid">
								    
                                   
								   <button onclick="$('.overlay#editEventSection').trigger('hide');return false;" id="closeMeatEventedit" class="btn btn-danger submt-btn">Close</button>
								   
								   <button type="submit" id="eventEditsubmit" class="btn btn-success submt-btn">Update</button>
									  <input type="hidden" id="eventPostId" value="" />
                                </div>
                            </form>
                       
                    </div>
                </div>
                <!-- /SECTION TILES -->

      
      
	
	
	
	
	

	<div class="overlay" id="forDelete">
      <div class="modal1" style="background:rgba(0,0,0,0.9); width: 12%;height: 20%;padding: 2%;box-shadow: 0px 4px 15px 2px rgba(19, 21, 24, 0.4);">
	<div class="simp-cls" style="position:absolute;top:0">  <a href="#!"  onclick="$('.overlay#forDelete').trigger('hide');return false;" >x</a></div>
         

                
               

                <!-- SECTION TILES -->
              
					<h3 class="block-title" style="">Delete confirmation</h3>
					<p style="margin:20px">Do you want to delete?</p>
                  
					<div class="row-fluid" id="">
                                    <input type="submit"  value='Yes' class="btn btn-success btn-delete-ys" id="deleteConfirmBtn" />
									<input onclick="$('.overlay#forDelete').trigger('hide');return false;" type="submit" id="NoDelete"  value='No'  class="btn btn-danger btn-delete-ys" /> 
                                </div>
      
      </div>
    </div>
		<script>
// var url = window.URL || window.webkitURL; // alternate use

function readImage(file,nameElement) {
    var input = $('#'+nameElement);
    var reader = new FileReader();
    var image  = new Image();
  
    reader.readAsDataURL(file);  
    reader.onload = function(_file) {
        image.src    = _file.target.result;              // url.createObjectURL(file);
        image.onload = function() {
            var w = this.width,
                h = this.height,
                t = file.type,                           // ext only: // file.type.split('/')[1],
                n = file.name,
                s = ~~(file.size/1024);
				//alert(s);
				
				if(s > 2048)
				{
				  alert('The file is too large');
				  input.replaceWith(input.val('').clone(true));
				  return false;
				}
		       if(nameElement == 'uploadPhoto')
			   {
                    $( "#img_container" ).empty();
			        $('#img_container').fadeIn(400).append('<img height="200" src="'+ this.src +'">');
			   }
			   else if(nameElement == 'editStatusPhoto')
			   {
			        $( "#img_container1" ).empty();
			        $('#img_container1').fadeIn(400).append('<img height="200" src="'+ this.src +'">');
			   }
        };
           image.onerror= function() {
            alert('Invalid file type: '+ file.type);
         };      
    };
    
}
$("#uploadPhoto").change(function (e) {
    if(this.disabled) return alert('File upload not supported!');
    var F = this.files;
    if(F && F[0]) for(var i=0; i<F.length; i++) readImage( F[i],'uploadPhoto' );
});

$("#editStatusPhoto").change(function (e) {
    if(this.disabled) return alert('File upload not supported!');
    var F = this.files;
    if(F && F[0]) for(var i=0; i<F.length; i++) readImage( F[i],'editStatusPhoto' );
});

</script>
	<script>
$(document).ready(function(){
		$("#mahajyothis_search").change(function(){
			
			setTimeout(function(){
			
			
	var name=$("#mahajyothis_search").val();
	if(name!='No User Found' & name.length >3){
	var groupID=<?php echo $this->session->userdata['groupID']; ?>;
	if(name!=''){
		$.ajax({
          url: "<?php echo base_url();?>groups/invitations?name="+name+"&gid="+groupID
        }).done(function( data ) {
		
		$("#mahajyothis_search").val('');
		$("#sent_information").html("<font color='white'>"+name+" </font><font color='yellow'>has been added...</font>").show();
		  return true;
        }); 
		}
	if(name==''){
		$("#mahajyothis_search").focus();	
	return false;
	}}
	}, 100 );
});
	});

</script>
	
 <script>
  $(document).ready(function(){
    $("body").hide(0).delay(0).slideDown(600)
    });
 
      $(document).ready(function() {
        $('.overlay').overlay();
      });
    </script>
<script>
$(document).ready(function() {

 $('#cmnt-area').hide();
  $('#up-fle').hide();
   $('#add-pst-vide').hide();
    $('#event-frmm').hide();

  $('#cmnt-boxx').css('cursor','pointer');
    $('#cmnt-boxx').click(function() {
        $('#cmnt-area').slideToggle();
    });
	
    $('#pst-even-mnu').click(function() {
         $('#add-pst-vide').hide();
		  $('#pst-dsply-blck').hide();
    $('#event-frmm').show();
    });
	 $('#pst-dsply-mnu').click(function() {
         $('#add-pst-vide').hide();
		  $('#pst-dsply-blck').show();
    $('#event-frmm').hide();
    });
	 $('#pst-img-mnu').click(function() {
         $('#add-pst-vide').show();
		  $('#pst-dsply-blck').hide();
    $('#event-frmm').hide();
    });
	
	
	 $('#write-something-cmnt').click(function() {
       
		$('#up-fle').show();
		
    });
	

	
});
</script>
<script>
$(document).ready(function() {
  $("a.fancybox").fancybox()
});
</script>
	     <?php include_once('assets/group_rakesh/js/groups.php');?>
		 <script src="<?php echo base_url('assets/group_rakesh/js/jquery-ui.js');?>"></script>
		 <script src="<?php echo base_url('assets/group_rakesh/js/script.js');?>"></script>
    </body>
</html>