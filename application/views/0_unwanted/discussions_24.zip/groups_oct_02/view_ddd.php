<!doctype html>
<html lang="en">
    <head>       
        <meta charset="utf-8" />
        <title><?php echo $results->grp_name;?></title>
        
        <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1, maximum-scale=1, user-scalable=no">

        <!--[if lt IE 9]><script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->

        <link href='http://fonts.googleapis.com/css?family=Open+Sans:300,600' rel='stylesheet' type='text/css'>

        
          <script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
         <script src="<?php echo base_url('assets/grouppage/group-page-innr/js/jquery.isotope.min.js');?>" type="text/javascript"></script> <!-- jQuery Library -->
         <script src="<?php echo base_url('assets/grouppage/group-page-innr/js/jquery.mousewheel.js');?>" type="text/javascript"></script> <!-- jQuery Library -->
         <script src="<?php echo base_url('assets/grouppage/group-page-innr/js/tileshow.js');?>" type="text/javascript"></script> <!-- jQuery Library -->
         <script src="<?php echo base_url('assets/grouppage/group-page-innr/js/script.js');?>" type="text/javascript"></script> <!-- jQuery Library -->
         
		 <script src="<?php echo base_url('assets/grouppage/group-page-innr/js/overlay.js');?>" type="text/javascript"></script> <!-- jQuery Library -->
         
		  <script src="<?php echo base_url('assets/grouppage/group-page-innr/js/jquery.mCustomScrollbar.js');?>" type="text/javascript"></script>
		  <script src="<?php echo base_url('assets/grouppage/group-page-innr/js/jquery.confirm.js');?>" type="text/javascript"></script>
		  <script src="<?php echo base_url('assets/grouppage/group-page-innr/js/bootstrap.min.js');?>" type="text/javascript"></script>
  
        <link href="<?php echo base_url('assets/grouppage/css/overlay.css');?>" rel="stylesheet">
		<link href="<?php echo base_url('assets/grouppage/css/style.css');?>" rel="stylesheet">
		<link href="<?php echo base_url('assets/grouppage/css/style-groups.css');?>" rel="stylesheet">
        <link href="<?php echo base_url('assets/grouppage/css/bootstrap-cols.css');?>" rel="stylesheet">
        <link href="<?php echo base_url('assets/grouppage/group-page-innr/css/style-grp-in.css');?>" rel="stylesheet">

       
    </head>
	
    <body>
	    
		<!--  DATA WE NEEDED -->
		  <?php 
                    $countData = count($userData);
                    $Countmembers =  count($members);
           ?>

        <div class="header">
            <div class="icn-bck-clsss">
										<a href="<?php echo base_url('groups'); ?>"><i class="fa fa-arrow-circle-o-left fa-4x"></i></a>
									<span style="font-size: 40px;
    padding: 44px;"><?php echo $results->grp_name; ?></span>

								</div>
        </div>
        <!-- /LOGO -->

        <!-- MAIN CONTENT SECTION -->
        <section id="content">

            
            <section class="clearfix section" id="about">

                <!-- SECTION TITLE -->
                <h3 class="block-title"></h3>
                <!-- /SECTION TITLE -->

                <!-- SECTION TILES -->
             

                <div class="tile black htmltile w3 h4">
                    <div class="tilecontent">
					
                        <div class="content">
						
						<div class="thumbnail prfl-img-cls" >
								<img src="<?=base_url()."uploads/groups/banners/".$results->grp_cover;?>" class="pf-img" alt="User Profile" />
								
										<div class="joind-clsss">
											  <?php if($this->session->userdata['profile_data'][0]['custID'] == $results->custID)
	              
				                               {
				                                 ?>
				   
					                           
											   <select class="slct-bck-clr">
												<option selected>Admin</option>
											   </select>
				 
				  
				  
				  <?php }  else
				        {
					
				        foreach($userData as $statusUser);
				        ?>
				    <?php if($countData != 0 && $statusUser->gistatus == 1)
				   {?>
				     

	  
											  <select class="slct-bck-clr" id="<?php echo $statusUser->giID;?>">
												<option selected>Joined</option>
												<option id='LeaveGroup'>Leave group</option>
												
											  </select> 
						
				 <?php }
				       else
					   {
				   ?>
        
		  <p class="slct-bck-clr" style="text-align:center;padding-top:5px;">
				      <a href="#"  id="JoinGroupIcon">
					  
					  + Join group
					
				     </a>
				
				  </p>
				  <?php } 
				        }
				  ?>
											  
											  
										</div>	
								
						</div>
                  </div>
				  
				  <div class="detls-sec-grp">
                           <p style="padding-right:23px;font-size:12px;line-height:18px;">
										<?php echo $results->grp_description; ?>
										
										 
									</p>
									<p>
									
									<div class="pull-left">
                                      <span class="mic-icn-grp" style="padding-right: 5px;"> <i class="fa fa-user"></i></span>
                                   </div>
							
									<span class="fnt-clr-clss"  style="padding-right: 0px;">  Group Created by <?php echo ucwords($results->custName); ?></span>
								   </p>
								
								<p>
									<div class="pull-left">
                                      <span class="mic-icn-grp" style="padding-right: 5px;"> <i class="fa fa-clock-o"></i></span>
                                   </div>
							
									<span class="fnt-clr-clss"  style="padding-right: 0px;">  <?php echo $this->custom_function->get_notification_time($this->config->item('global_datetime'),$results->doDate);?></span>
									</p>
									
									
									</div><div class="members-lst-cls">
								<div class="membrs-count">
									<p>(240) Members</p>
											<div class="input-grps">
												  <span class="input-grps-icnn" id="sizing-addon1" style="padding-top: 8px;">+</span>
												  <input type="text" class="input-grps-rght" placeholder="Add Members" style="padding-bottom: 1px;padding-top: 5px;">
											</div>
											<marquee>
		<div class="col-md-12">
			<img src="img/profile.jpg" style="width: 50px;">
		
		
			<img src="img/profile.jpg" style="width: 50px;">
		
		
			<img src="img/profile.jpg" style="width: 50px;">
		
		
			<img src="img/profile.jpg" style="width: 50px;">
		
		
			<img src="img/profile.jpg" style="width: 50px;">
		
			<img src="img/profile.jpg" style="width: 50px;">
			<img src="img/profile.jpg" style="width: 50px;">
		
			<img src="img/profile.jpg" style="width: 50px;">
			<img src="img/profile.jpg" style="width: 50px;">
		
			<img src="img/profile.jpg" style="width: 50px;">
		</div>	
		</marquee>
								</div>
							</div>
                    <pre></pre>
						</div>
						
                    </div>
                </div>
                <!-- /SECTION TILES -->

            </section>
            <?php if(($this->session->userdata['profile_data'][0]['custID'] == $results->custID) || ($countData != 0 && $statusUser->gistatus == 1))
				   {?>
          <section class="clearfix section" id="contactform">

                <!-- SECTION TITLE -->
                <h3 class="block-title">Update what you like now?</h3>
                <!-- /SECTION TITLE -->

                <!-- SECTION TILES -->
                <div class="tile black htmltile w3 h4">
                    <div class="tilecontent">
                        <div class="content">

						
						<ul class="listmnu">
							<li id="pst-dsply-mnu">Posts</li>
							<li id="pst-even-mnu">Events</li>
							<li id="pst-img-mnu">Add Photo / Video</li>
							
						</ul>
						
						<div class="comment-area" style="transition:all 1s ease-in-out;">
							<div id="pst-dsply-blck">
							 <form class="form-horizontal" role="form">
							<textarea class="commnt-txtara" name="postApostBox" id="postApostBox" placeholder="Update your status"></textarea>
							
									<div class="submit-btnn-cls" style="">
									<input type="button" value="submit" id="postApost" class="btn btn-danger submt-btn">
									</div>
									</form>
							</div>			 
								</div>													
		
								<div id="event-frmm">
								
								
								
								
                            <form id="contactme" class="form-dark" name="">
                                <div class="row-fluid"  style="margin-top:15px;">
                                    <label>Event Title </label>
                                    <input type="text" class="span12" placeholder="Group Name">
                                </div>
								<div class="row-fluid"  >
                                    <label>Description</label>
                                    <textarea class="span12" placeholder="Group Discussion"></textarea>
                                </div>
								<div class="row-fluid"  >
                                    <label>Location</label>
                                    <textarea class="span12" placeholder="Group Discussion"></textarea>
                                </div>
                               
                                <div class="row-fluid">
                                    <button type="submit" class="btn btn-info btn-block pull-right">Submit</button>
                                </div>
                            </form>
							</div>
							<div id="add-pst-vide">
                       <input type="file">
							</div>
						</div>
		
                        </div>
                    </div>
                </div>
                <!-- /SECTION TILES -->

            </section>
			<?php } ?>
			 <section class="clearfix section" id="contactform">

                <!-- SECTION TITLE -->
                <h3 class="block-title">Posts</h3>
                <!-- /SECTION TITLE -->
                
                <!-- SECTION TILES -->
                <div class="tile black htmltile w3 h4">
                    <div class="tilecontent">
                        <div class="content">
					     <?php  
							
							    if(empty($posts))
                                {
								   
								   echo "No posts found...!";
								}
								else
								{
                                 //print_r($posts);
								foreach($posts as $post)
						         {
						     ?>
						<div class="pst-cntnts" style="height:100%; margin-top: 16px;">
							<div class="img-cntnr thumbnail">
							
								<img src="<?php echo base_url().UPLOADS.$post->photo;?>" class="pf-img-pst" alt="User Profile" />
						</div>
							<div class="usr-pfle-nme">
							<div class="pst-nmes-clss">
								<h3><?php echo $post->custName;?></h3>
								<p><?php echo $this->custom_function->get_notification_time($this->config->item('global_datetime'),$post->doDate);?></p>
							</div>
							
							
							
							<?php if($post->custID == $this->session->userdata['profile_data'][0]['custID'] || $this->session->userdata['profile_data'][0]['custID'] == $results->custID){ ?>
			<!--<span class="userAction" id="<?php echo $post->id;?>">
				
			 <p class="userActions pull-right" id="<?php echo $post->id;?>">
							
                                  <small><a href="#deleteConfirmation" data-toggle="modal" data-target="#deleteConfirmation" class="deleteConfirmation"><span class="glyphicon glyphicon-remove-circle"></span> Delete</a></small>
                                  <small><a href="#<?php echo $data_target;?>" data-toggle="modal" data-target="#<?php echo $data_target;?>" class="<?php echo $class; ?>"><span class="glyphicon glyphicon-edit"></span> Edit</a></small>
                                </p>
			</span> -->
							
							
							<div class="userActions pst-editdel-clss" id="<?php echo $post->id;?>">
							
							<?php
								switch($post->postType){
									case 1 : $class = 'editData';
											 $data_target = 'exampleModalGroupEdit';
											break;								
									case 2 : $class = 'editDataEvent';
											$data_target = 'editEvent';
											break;
									case 3 : $class = 'editDataPhotoPost';
											$data_target = 'exampleModalEditPhoto';
											break;
								}
							?>
							
							
								<a data-overlay-trigger="one" href="#!"><span class="icn-spce-grp"><i class="fa fa-pencil-square-o" style="color:#fff"></i></span></a> <a data-overlay-trigger="one" href="#!"><span  class="textcnt-spce-grp fnt-clr-clss">Edit</span></a><span  class="icn-spce-grp"><i class="fa fa-trash-o" style="color:#fff"></i></span><span class="fnt-clr-clss">Delete</span>
							</div>
							<?php } ?>
							</div>
						  
						  <div>
						 <p style="padding: 10px;">here is my comment here is my comment here is my comment here is my comment here is my comment here is my comment here is my comment here is my comment</p>
						  </div>
						 
                          <div class="pstdd-img thumbnail" style="border: none;
padding: 0.111%;">
								<img src="http://mahajyothis.net.local/uploads/groups/banners/banner11.jpg" class="img-responsive" alt="User Profile" />
						  </div>
						  <div class="lke-cmnt">
								<span class="pst-lke"><i class="fa fa-thumbs-o-up" style="padding-right:5px"></i>like</span><span class="pst-cmntss" id="cmnt-boxx"><i class="fa fa-comment" style="padding-right:5px"></i>comment</span>
						  </div>
						  <div  id="cmnt-area">
						  <textarea placeholder="Comment Here . . ." style="width: 79%;
    height: 35px; background:rgba(0,0,0,0.7)"></textarea>
						  <input type="submit" class="btn btn-danger pull-right" value="Submit">
						  </div>
						  
</div>
<?php } }?>
                         <div class="cmnt-area-bottm" style="height: 71px;
background: #120A0A; ">
						  <div class="thumbnail" style="float:left; border:none; padding:0 15px 0 0">
							
								<img src="img/profile2.jpg" class="pf-img-pst" alt="User Profile" />
						</div>
							<div class="usr-pfle-cmnt" ><h3>Theiventhiran</h3>
							<p style="margin-left: 61px;">here is my comment</p>
							<span style="   
      padding: 15px 15px 15px 0;">(59)<i class="fa fa-thumbs-up" style="padding-right: 3px;     padding-left: 3px; "></i>like</span><span style="    
       padding: 15px;
    margin-left: -15px;">(59)<i class="fa fa-reply" style="padding-right: 3px;    padding-left: 3px;"></i>Reply</span>
							</div>
							</div>
                        </div>
                    </div>
                </div>
                <!-- /SECTION TILES -->

            </section>

        </section> 
        <!-- /MAIN CONTENT SECTION -->
<div class="overlay" id="one">
      <div class="modal1" style="background:rgba(0,0,0,0.9); width: 38%;height: 79%;padding: 2%;box-shadow: 0px 4px 15px 2px rgba(19, 21, 24, 0.4);">
	<div class="simp-cls" style="position:absolute;top:0">  <a href="#!"  onclick="$('.overlay#one').trigger('hide');return false;" >x</a></div>
         

                <!-- SECTION TITLE -->
                <h3 class="block-title" style="margin-top: 1px;
margin-left: 9px;">Edit Group</h3>
                <!-- /SECTION TITLE -->

                <!-- SECTION TILES -->
                <div class="tile black htmltile w3 h4" style="width:95%; margin-top:3px; height:100%">
                    <div class="tilecontent">
						

                            

                           

                            <form id="contactme" class="form-dark" name="cform" method="post" action="">
                                <div class="row-fluid"  style="margin-top:15px;">
                                    <label>Group Name </label>
                                    <input type="text" class="span12" placeholder="Group Name">
                                </div>
								<div class="row-fluid"  >
                                    <label>Group Discussion</label>
                                    <textarea class="span12" placeholder="Group Discussion"></textarea>
                                </div>
                                <div class="row-fluid">
                                    <label>Group Cover: </label>
                                    <img src="" style="width:100%; height:200px">
									<input type="file">
                                </div>
                               
                                <div class="row-fluid">
                                    <label>Privacy</label>
                                    <select id="subject" name="subject" class="span12">
                                        <option value="service">private Group</option>
                                        <option value="suggestions">Public Group</option>
                                        
                                    </select>
                                </div>

                               
                                <div class="row-fluid">
                                    <button type="submit" class="btn btn-info btn-block pull-right">Submit</button>
                                </div>
                            </form>
                       
                    </div>
                </div>
                <!-- /SECTION TILES -->

      
      </div>
    </div>

 <script>
  $(document).ready(function(){
    $("body").hide(0).delay(0).slideDown(600)
    });
 
      $(document).ready(function() {
        $('.overlay').overlay();
      });
    </script>
<script>
$(document).ready(function() {
 $('#cmnt-area').hide();
  $('#up-fle').hide();
   $('#add-pst-vide').hide();
    $('#event-frmm').hide();

  $('#cmnt-boxx').css('cursor','pointer');
    $('#cmnt-boxx').click(function() {
        $('#cmnt-area').slideToggle();
    });
	
    $('#pst-even-mnu').click(function() {
         $('#add-pst-vide').hide();
		  $('#pst-dsply-blck').hide();
    $('#event-frmm').show();
    });
	 $('#pst-dsply-mnu').click(function() {
         $('#add-pst-vide').hide();
		  $('#pst-dsply-blck').show();
    $('#event-frmm').hide();
    });
	 $('#pst-img-mnu').click(function() {
         $('#add-pst-vide').show();
		  $('#pst-dsply-blck').hide();
    $('#event-frmm').hide();
    });
	
	
	 $('#write-something-cmnt').click(function() {
       
		$('#up-fle').show();
		
    });
});
</script>
<?php include_once('assets/group_rakesh/js/groups.php');?>
    </body>
</html>