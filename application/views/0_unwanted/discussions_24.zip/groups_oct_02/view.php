<!doctype html>
<html lang="en">
    <head>       
        <meta charset="utf-8" />
        <title><?php echo $results->grp_name;?></title>
        
        <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1, maximum-scale=1, user-scalable=no">

        <!--[if lt IE 9]><script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->

        <link href='http://fonts.googleapis.com/css?family=Open+Sans:300,600' rel='stylesheet' type='text/css'>

        <script>var ver172 = $.noConflict();</script>
		 
		  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
		  
		 <script src="<?php echo base_url('assets/js/jquery.autocomplete.js');?>"></script>
		 <script>
			$(document).ready(function (ver172) {
				  ver172("#mahajyothis_search").autocomplete("<?php echo base_url()?>groups/groupmembers", {
						selectFirst: true
				  });
		 });
		</script>
          <script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
		  
         <script src="<?php echo base_url('assets/grouppage/group-page-innr/js/jquery.isotope.min.js');?>" type="text/javascript"></script> <!-- jQuery Library -->
		 
         <script src="<?php echo base_url('assets/grouppage/group-page-innr/js/jquery.mousewheel.js');?>" type="text/javascript"></script> <!-- jQuery Library -->
		 
         <script src="<?php echo base_url('assets/grouppage/group-page-innr/js/tileshow.js');?>" type="text/javascript"></script> <!-- jQuery Library -->
		 
		 
         <script src="<?php echo base_url('assets/grouppage/group-page-innr/js/script.js');?>" type="text/javascript"></script> <!-- jQuery Library -->
         
		 <script src="<?php echo base_url('assets/grouppage/group-page-innr/js/overlay.js');?>" type="text/javascript"></script> <!-- jQuery Library -->
         
		  <script src="<?php echo base_url('assets/grouppage/group-page-innr/js/jquery.mCustomScrollbar.js');?>" type="text/javascript"></script>
		  
		  <script src="<?php echo base_url('assets/grouppage/group-page-innr/js/jquery.confirm.js');?>" type="text/javascript"></script>
		 
		 <script src="<?php echo base_url('assets/grouppage/group-page-innr/js/bootstrap.min.js');?>" type="text/javascript"></script>
  
        <link href="<?php echo base_url('assets/grouppage/css/overlay.css');?>" rel="stylesheet">
		<link href="<?php echo base_url('assets/grouppage/css/style.css');?>" rel="stylesheet">
		<link href="<?php echo base_url('assets/grouppage/css/style-groups.css');?>" rel="stylesheet">
        <link href="<?php echo base_url('assets/grouppage/css/bootstrap-cols.css');?>" rel="stylesheet">
        <link href="<?php echo base_url('assets/grouppage/group-page-innr/css/style-grp-in.css');?>" rel="stylesheet">
		<link href="<?php echo base_url('assets/group_rakesh/css/jquery-ui.css');?>" rel="stylesheet">

       <style>
	   .ac_results li{
		   z-index:9999;
		   color:white;
		 background-color: #DA4F49;
		 padding:3%;
		 width:100%
	   }
	   .ac_results li:hover{ cursor:pointer}
	   .ac_results{    z-index: 999999;
    width: 361px !important;}
	   
	   </style>
    </head>
	
    <body>
	    
		<!--  DATA WE NEEDED -->
		  <?php 
                    $countData = count($userData);
                    $Countmembers =  count($members);
           ?>

        <div class="header">
            <div class="icn-bck-clsss">
										<a href="<?php echo base_url('groups'); ?>"><i class="fa fa-arrow-circle-o-left fa-4x"></i></a>
									<span style="font-size: 40px;
    padding: 44px;"><?php echo $results->grp_name; ?></span>

								</div>
        </div>
        <!-- /LOGO -->

        <!-- MAIN CONTENT SECTION -->
        <section id="content">

            
            <section class="clearfix section" id="about">

                <!-- SECTION TITLE -->
                <h3 class="block-title"></h3>
                <!-- /SECTION TITLE -->

                <!-- SECTION TILES -->
             

                <div class="tile black htmltile w3 h4">
                    <div class="tilecontent">
					
                        <div class="content">
						
						<div class="thumbnail prfl-img-cls" >
								<img src="<?=base_url()."uploads/groups/banners/".$results->grp_cover;?>" class="pf-img" alt="User Profile" />
								
										<div class="joind-clsss">
											  <?php if($this->session->userdata['profile_data'][0]['custID'] == $results->custID)
	              
				                               {
				                                 ?>
				   
					                           
											   <select class="slct-bck-clr">
												<option selected>Admin</option>
											   </select>
				 
				  
				  
				  <?php }  else
				        {
					
				        foreach($userData as $statusUser);
				        ?>
				    <?php if($countData != 0 && $statusUser->gistatus == 1)
				   {?>
				     

	                                      <p class="slct-bck-clr" id="<?php echo $statusUser->giID; ?>" style="text-align:center;padding-top:5px;">
											
											<a href="#" id='LeaveGroup'>Leave group</a>
											</p>
						
				 <?php }
				       else
					   {
				   ?>
        
		  <p class="slct-bck-clr" style="text-align:center;padding-top:5px;">
				      <a href="#"  id="JoinGroupIcon">
					  
					  + Join group
					
				     </a>
				
				  </p>
				  <?php } 
				        }
				  ?>
											  
											  
										</div>	
								
						</div>
                  </div>
				  
				  <div class="detls-sec-grp">
                           <p style="padding-right:23px;font-size:12px;line-height:18px;">
										<?php echo $results->grp_description; ?>
										
										 
									</p>
									<p>
									
									<div class="pull-left">
                                      <span class="mic-icn-grp" style="padding-right: 5px;"> <i class="fa fa-user"></i></span>
                                   </div>
							
									<span class="fnt-clr-clss"  style="padding-right: 0px;">  Group Created by <?php echo ucwords($results->custName); ?></span>
								   </p>
								
								<p>
									<div class="pull-left">
                                      <span class="mic-icn-grp" style="padding-right: 5px;"> <i class="fa fa-clock-o"></i></span>
                                   </div>
							
									<span class="fnt-clr-clss"  style="padding-right: 0px;">  <?php echo $this->custom_function->get_notification_time($this->config->item('global_datetime'),$results->doDate);?></span>
									</p>
									
									
									</div><div class="members-lst-cls">
								<div class="membrs-count">
									<p>(<?php echo $Countmembers+1;?>) Members</p>
							<?php		if($this->session->userdata['profile_data'][0]['custID'] == $results->custID)
									{ ?>
											<div class="input-grps">
												  <span class="input-grps-icnn" id="sizing-addon1" style="padding-top: 8px;">+</span>
												  <input type="text" class="input-grps-rght" id="mahajyothis_search" placeholder="Add Members" style="padding-bottom: 1px;padding-top: 5px;">
											</div>
											<span id="sent_information"></span>
									<?php } ?>
											
		<div class="col-md-12">
		
		<img title="admin" style="width: 50px;height: 50px;" src="<?php echo ($results->photo && file_exists(UPLOADS.$results->photo)) ? base_url().UPLOADS.$results->photo : base_url().UPLOADS.'profile.png';?>" >
		
		 <?php if($Countmembers != 0)
		   {
		      foreach($members as $member)
			  {
			   ?>
			      <img title="<?php echo $member->custName;?>" style="width: 50px;height: 50px;" src="<?php echo ($member->photo && file_exists(UPLOADS.$member->photo)) ? base_url().UPLOADS.$member->photo : base_url().UPLOADS.'profile.png';?>" >
			  <?php
			  }
			  
		          
		   }
		?>
		<!--	<img src="img/profile.jpg" style="width: 50px;">
		
		
			<img src="img/profile.jpg" style="width: 50px;">
		
		
			<img src="img/profile.jpg" style="width: 50px;">
		
		
			<img src="img/profile.jpg" style="width: 50px;">
		
		
			<img src="img/profile.jpg" style="width: 50px;">
		
			<img src="img/profile.jpg" style="width: 50px;">
			<img src="img/profile.jpg" style="width: 50px;">
		
			<img src="img/profile.jpg" style="width: 50px;">
			<img src="img/profile.jpg" style="width: 50px;">
		
			<img src="img/profile.jpg" style="width: 50px;"> -->
		</div>	
	
								</div>
							</div>
                    <pre></pre>
						</div>
						
                    </div>
                </div>
                <!-- /SECTION TILES -->

            </section>
            <?php if(($this->session->userdata['profile_data'][0]['custID'] == $results->custID) || ($countData != 0 && $statusUser->gistatus == 1))
				   {?>
          <section class="clearfix section" id="contactform">

                <!-- SECTION TITLE -->
                <h3 class="block-title">Update what you like now?</h3>
                <!-- /SECTION TITLE -->

                <!-- SECTION TILES -->
                <div class="tile black htmltile w3 h4">
                    <div class="tilecontent">
                        <div class="content">

						
						<ul class="listmnu">
							<li id="pst-dsply-mnu">Posts</li>
							<li id="pst-even-mnu">Events</li>
							<li id="pst-img-mnu">Add Photo</li>
							
						</ul>
						
						<div class="comment-area" style="transition:all 1s ease-in-out;">
							<div id="pst-dsply-blck">
							 <form class="form-horizontal" role="form">
							<textarea class="commnt-txtara" name="postApostBox" id="postApostBox" placeholder="Update your status"></textarea>
							
									<div class="submit-btnn-cls" style="">
									<input type="submit" value="Post" id="postApost" class="btn btn-danger submt-btn">
									</div>
									</form>
							</div>			 
								</div>													
		
								<div id="event-frmm">
								
							
								
								
                            <form id="contactme" class="form-dark" name="">
                                <div class="row-fluid"  style="margin-top:15px;">
                                    <label>Event Title </label>
                                    <input type="text" class="span12" id="eventTitle" name="eventTitle" placeholder="Event title">
                                </div>
								
								<div class="row-fluid"  >
                                    <label>Location</label>
                                   
									<input type="text" class="span12" id="eventLocation" name="eventLocation" placeholder="Event location" /> 
                                </div>
                               
							   <div class="row-fluid"  >
                                    <label>Event date</label>
                                   
									<input type="text" class="span12 eventDate" id="eventDate" name="eventDate" placeholder="Event date" placeholder="Event date" /> 
                                </div>
							   
							   
							   <div class="row-fluid"  >
                                    <label>Event description</label>
                                    <textarea class="span12" name="eventDes" id="eventDes" placeholder="Tell about event..."></textarea>
                                </div>
                                <div class="row-fluid">
                                    <input type="submit"  value='Create' id="postAevent" class="btn btn-danger submt-btn" />
                                </div>
                            </form>
							</div>
							<div id="add-pst-vide">
							 <form class="form-horizontal" method="post" enctype="multipart/form-data" action="<?php echo base_url().'groups/doPostwithImage/'.$r;?>" role="form">
							   
							    <div class="row-fluid">
								  <label>Upload photo</label>
							   <input type="file" class="span12" name="uploadPhoto" id="uploadPhoto" accept='image/*' required>
									  
									</div>  
									  <div class="row-fluid">
							 
							 <textarea class="commnt-txtara" name="postTextinImage" id="postTextinImage" required placeholder="What you want to say..!"></textarea>
							</div>
                                    
                                    <input type="submit"  value='Post' class="btn btn-danger submt-btn" />
									
									</form>
                                
							</div>
						</div>
		                  <?php if(empty($posts))
                                {
								   
								   echo "No posts found...!";
								}?>
                        </div>
						
                    </div>
                </div>
                <!-- /SECTION TILES -->

            </section>
			<?php } ?>
			
					     <?php  
							
							    if(empty($posts))
                                {
								   
								   echo "";
								}
								else
								{
                                 //print_r($posts);
								$i = 1;
								
								$header_content = "<section class='clearfix section' id='contactform'><div class='tile black htmltile w3 h4'><div class='tilecontent'><div class='content'>";
								 $footer_content = "</div></div></div>
                                     </section>";
								foreach($posts as $post)
						         {
								    
									
									if($i == 5 || $i == 1 )
									 {
									     echo $header_content;
										 $i = 1;
									 }
								 
								 
								
								
						     ?>
							 
							 
						<div class="pst-cntnts" style="height:100%; margin-top: 16px;" id="singlePost_<?php echo $post->id;?>">
							<div class="img-cntnr thumbnail">
							
								<img src="<?php echo base_url().UPLOADS.$post->photo;?>" class="pf-img-pst" alt="User Profile" />
						</div>
							<div class="usr-pfle-nme">
							<div class="pst-nmes-clss">
								<h3><?php echo $post->custName;?></h3>
								<p><?php echo $this->custom_function->get_notification_time($this->config->item('global_datetime'),$post->doDate);?></p>
							</div>
							
							
							
							<?php if($post->custID == $this->session->userdata['profile_data'][0]['custID'] || $this->session->userdata['profile_data'][0]['custID'] == $results->custID){ ?>
			<!--<span class="userAction" id="<?php echo $post->id;?>">
				
			 <p class="userActions pull-right" id="<?php echo $post->id;?>">
							
                                  <small><a href="#deleteConfirmation" data-toggle="modal" data-target="#deleteConfirmation" class="deleteConfirmation"><span class="glyphicon glyphicon-remove-circle"></span> Delete</a></small>
                                  <small><a href="#<?php echo $data_target;?>" data-toggle="modal" data-target="#<?php echo $data_target;?>" class="<?php echo $class; ?>"><span class="glyphicon glyphicon-edit"></span> Edit</a></small>
                                </p>
			</span> -->
							
							
							<div class="userActions pst-editdel-clss" id="<?php echo $post->id;?>">
							
							<?php
								switch($post->postType){
									case 1 : $class = 'editData';
											 $data_target = 'editStatusInGroupsInner';
											break;								
									case 2 : $class = 'editDataEvent';
											$data_target = 'editEventSection';
											break;
									case 3 : $class = 'editDataPhotoPost';
											$data_target = 'editStatusWithPhoto';
											break;
								}
							?>
							
							
								<a data-overlay-trigger="<?php echo $data_target;?>" class="<?php echo $class;?>" href="#!"><span class="icn-spce-grp"><i class="fa fa-pencil-square-o" style="color:#fff"></i></span><span  class="textcnt-spce-grp fnt-clr-clss">Edit</span></a>
								
								<a href='#' class="Del_post" data-overlay-trigger="forDelete"><span  class="icn-spce-grp"><i class="fa fa-trash-o" style="color:#fff"></i></span><span class="fnt-clr-clss" >Delete</span></a>
							</div>
							<?php } ?>
							</div>
						  
						<?php if($post->postType ==2) {  ?>
			<div class="col-md-12" style="background-image:url(<?php echo base_url('uploads/events/'.rand(1,10).'.jpg');?>);color:#fff;padding:10px;padding-bottom:30px;text-align:center;">
		    <h2 class="PostedEventtitle"><?php echo $post->eventTitle;?> </h2>
			<p class="PostedEventContent" style="padding:4px"><?php echo $post->postContent;?></p>
		    <h3 class="PostedEventDate"><i class="fa fa-calendar-times-o"></i> <?php echo $post->eventDate;?> </h3>
		    <h4 class="PostedEventLocation" style="font-size:14px"><i class="fa fa-map-marker"></i> <?php echo $post->eventLocation;?> </h4>
			
		</div>
		  <?php } if($post->postType == 1) { ?>
		<div class="col-md-12">
			<p class="postContent" style="clear: both;"><?php echo $post->postContent;?> </p>
		</div> 
		<?php } ?>
						  
                           <?php if($post->postType ==3) {  ?>
						    <p style="padding: 10px;clear: both;" class="postContent">
							<?php echo $post->postContent;?>
							</p>
		   <div class="pstdd-img thumbnail" style="border: none;
padding: 0.111%;">
			<img src="<?php echo base_url('uploads/groups/posts').'/'.$post->postImage;?>" class="img-responsive" style="width: 100%;">
		</div>
		<?php } ?>
						   <?php if(($this->session->userdata['profile_data'][0]['custID'] == $results->custID) || ($countData != 0 && $statusUser->gistatus == 1))
				   {?>
						  <div class="lke-cmnt" style="clear:both">
						  <span style="font-weight:bold;color:green;">(<span id="user_likes<?php echo $post->id; ?>">
		<?php 
								 $cat="GROUP";
		
		
		$like_count="SELECT COUNT(`catID`) AS `total_likes` FROM `recentactivity` WHERE `raCategory`='$cat' AND `catID`='".$post->id."' AND `raAction`='LIKE' ";
		$like = $this->db->query($like_count);
		$like_row=$like->result_array();
		
		echo $like_row[0]['total_likes'];  ?>
		
		
		
		
		</span>)</span>
		<?php
								$cat="GROUP";
		
		 $profile_row = $this->session->userdata('profile_data');
		
		$likeed="SELECT * FROM `recentactivity` WHERE `raCategory`='$cat' AND `catID`='".$post->id."' AND `raAction`='LIKE' AND `custID`='".$profile_row['0']['custID']."' ";
		$liked_process = $this->db->query($likeed);
		if($liked_process->num_rows() >= 1){ 
                                 ?>
		
		
								<span class="pst-lke"><i class="fa fa-thumbs-up" style="padding-right:5px;color:green;" ></i>liked</span>
								
		<?php } else { ?>
		
			<span class="pst-lke"><i class="fa fa-thumbs-o-up" style="padding-right:5px;" onclick="like<?php echo $post->id; ?>()"></i>like</span>
		<?php }?>
								<span style="color:green" >(<span id="recent_comment_count<?php echo $post->id;?>"> <?php 

								
									$cat="GROUP";
		
		
		$comment_count="SELECT COUNT(`catID`) AS `total_comments` FROM `recentactivity` WHERE `raCategory`='$cat' AND `catID`='".$post->id."' AND `raAction`='COMMENT' ";
		$comment = $this->db->query($comment_count);
		$comment_row=$comment->result_array();


								echo $comment_row[0]['total_comments'];  ?></span>) </span>
								<span class="pst-cmntss" id="cmnt-boxx_<?php echo $post->id;?>"><i class="fa fa-comment" style="padding-right:5px;"></i>comment</span>
						  </div>
						  <div class="com" id="comments3" >
						  <div class="coment_display">
	
						  <div id="recent_comment<?php echo $post->id;?>">
						  
        <?php $select_comment="SELECT * FROM `useraction` ua
		LEFT JOIN `customermaster` cm ON(cm.`custID`=ua.`custID`)
		LEFT JOIN `personalphoto` pp ON(pp.`custID` = cm.`custID`)
		WHERE ua.`uaCategory`='GROUP' AND ua.`catID`='".$post->id."' ORDER BY ua.`uaID` DESC LIMIT 4
		";
		$select_com = $this->db->query($select_comment);
		foreach($select_com->result() as $row)
        {
        ?>
		
		 <div class="coment_display" style="margin:5%">
		<img src="/uploads/<?php 
			if(ISSET($row->photo)){
				echo $row->photo;
			}
			else{
				echo "profile.png";
			}
			
			
			?>" style="width:30px;float:left">
		<p style="margin-left:12%"><?php echo $row->uaDescription;?></p>
		</div>
		
		
			

		<?php
		}
		?></div>
            <p class="d_c" style=" margin-top: 38px"></p>
            <!--------------------------------------------------------------------------------------------------->

            <a href="javascript:void(0)" class="view_more_post_comments" style="color: darkgreen; font-weight: bold">view more comments</a>

            <input type="hidden" id="get_postid" class="get_postid" value="<?php echo $post->id;?>">
            <input type="hidden"  class="increment_number" value="4">
            <!--------------------------------------------------------------------------------------------------->
        </div>
						  
						  <div  id="cmnt-area_<?php echo $post->id;?>" style="display:none;">
						  <textarea id="user_comment<?php echo $post->id; ?>" placeholder="Comment Here . . ." style="width: 79%;
    height: 35px; background:rgba(0,0,0,0.7)"></textarea>
						  <input type="submit" onclick="comment<?php echo $post->id; ?>()" class="btn btn-danger pull-right" value="Submit">
						  </div>
						  
						  <script>
						  $(document).ready(function() {
						  $('#cmnt-boxx_<?php echo $post->id;?>').css('cursor','pointer');
                          $('#cmnt-boxx_<?php echo $post->id;?>').click(function() {
                          $('#cmnt-area_<?php echo $post->id;?>').slideToggle();
                               });
                             });
	</script>
	
	
	
	<?php } ?>
					  <script>

function like<?php echo $post->id; ?>(){
	
	var cid="<?php  echo $this->session->userdata['profile_data'][0]['custID'];   ?>";
	var pid="<?php echo $post->custID; ?>";
	var cat="GROUP";
	var act="LIKE";
	var page="recentactivity";
	
	var catid="<?php echo $post->id; ?>";
	$.ajax({
          url: "<?php echo base_url();?>like?cid="+cid+"&& uid="+pid+"&& cat="+cat+"&& act="+act+"&& page="+page+"&catid="+catid
        }).done(function( data ) {
			
			
    $("#user_like<?php echo $post->id; ?>").html("<span class='small fa fa-thumbs-up ' style='color:green'>Liked</span>");
	$("#user_likes<?php echo $post->id; ?>").load('<?php echo base_url(); ?>groups/recent_like_count?id_post='+catid);
	

		  return true;
        }); 
	
}

	</script>
	<script>
 function comment<?php echo $post->id; ?>() 
 {
	
	var comment_user = $("#user_comment<?php echo $post->id; ?>").val()
	if(comment_user == "")
	{
		$("#user_comment<?php echo $post->id; ?>").focus();
		
	}
	else
	{
	var user_comment = $("#user_comment<?php echo $post->id; ?>").val();
	var uid = "<?php echo $post->custID; ?>";
	var cid = "<?php echo $this->session->userdata['profile_data'][0]['custID'];  ?>";
	var pid="<?php echo $post->id; ?>";
    var cat="GROUP";
	
	var act="COMMENT";
	
      if(user_comment!=''){
        $.ajax({
          url: "<?php echo base_url();?>activity?user_comment="+user_comment+"&uid="+uid+"&cid="+cid+"&pid="+pid+"&cat="+cat+"&act="+act
        }).done(function( data ) {
	
		  return true;
        });   
		  $.ajax({
          url: "<?php echo base_url();?>groups/recent_comments"
        }).done(function( data ) {
	 $("#recent_comment<?php echo $post->id;?>").load('<?php echo base_url(); ?>groups/recent_comments?id_post='+pid);
	 $("#user_comment<?php echo $post->id;?>").val('');
		  return true;
        });  
		  $.ajax({
          url: "<?php echo base_url();?>groups/recent_comment_count"
        }).done(function( data ) {
	
	$("#recent_comment_count<?php echo $post->id;?>").load('<?php echo base_url(); ?>groups/recent_comment_count?id_post='+pid);
		  return true;
        });  
		
		
		
		
      } 
	  
	
    }
 }
  
  </script>
	  
	   	 

						 
</div>
<?php $i++; 

if($i == 5)
									 {
									     echo $footer_content;
										
									 }
} }?>
                        
                     

					
        </section> 
   

	
	
	<div class="overlay" id="editStatusInGroupsInner">
      <div class="modal1" style="background:rgba(0,0,0,0.9); width: 30%;height:25%;padding: 1%;box-shadow: 0px 4px 15px 2px rgba(19, 21, 24, 0.4);">
	<div class="simp-cls" style="position:absolute;top:0">  <a href="#!"  onclick="$('.overlay#editStatusInGroupsInner').trigger('hide');return false;" >x</a></div>
         

                <!-- SECTION TITLE -->
               
                <!-- /SECTION TITLE -->

                <!-- SECTION TILES -->
                <div class="tile black htmltile w3 h4" style="width:95%; margin-top:3px; height:100%">
                    <div class="tilecontent">
					 <h3 class="block-title" style="margin-top: 15px;
margin-left: 9px;">Edit Status</h3>
                            <form id="contactme" class="form-dark" name="cform" method="post" action="">
                               
								<div class="row-fluid"  >
                                   
                                    <textarea class="span12" name="editPostContent" id="editPostContent"></textarea>
                                </div>
                            
                                <div class="row-fluid">
								    
                                   
								   <button onclick="$('.overlay#editStatusInGroupsInner').trigger('hide');return false;" id="CloseMeatEDIT" class="btn btn-danger submt-btn">Close</button>
								   
								   <button type="submit" id="editSavePost" class="btn btn-success submt-btn">Update</button>
									 <input type="hidden" id="editPostId" value="" />
                                </div>
                            </form>
                       
                    </div>
                </div>
                <!-- /SECTION TILES -->

      
      </div>
    </div>
	
	
	<div class="overlay" id="editStatusWithPhoto">
      <div class="modal1" style="background:rgba(0,0,0,0.9); width: 40%;height:55%;padding: 1%;box-shadow: 0px 4px 15px 2px rgba(19, 21, 24, 0.4);">
	<div class="simp-cls" style="position:absolute;top:0">  <a href="#!"  onclick="$('.overlay#editStatusWithPhoto').trigger('hide');return false;" >x</a></div>
         

                <!-- SECTION TITLE -->
               
                <!-- /SECTION TITLE -->

                <!-- SECTION TILES -->
                <div class="tile black htmltile w3 h4" style="width:95%; margin-top:3px; height:100%">
                    <div class="tilecontent">
					 <h3 class="block-title" style="margin-top: 15px;
margin-left: 9px;">Edit Status with Photo</h3>
                           <form method="post" class="form-dark" action="<?php echo base_url().'groups/updatePostwithImage/'.$r;?>" enctype="multipart/form-data">
                               
								<div class="row-fluid">
                                    
                                    <textarea class="span12" name="editPhotoContent" id="editPhotoContent"></textarea>
                                </div>
								<div class="row-fluid">
                            <div id="img_container"></div>
							 <label>Change Image </label>
                             
							 <input type="file" class="form-control" name="editStatusPhoto" id="editStatusPhoto">
			                 <input type="hidden" id="editStatusPhotoId" name="editStatusPhotoId" value="" />
							
							</div>
							
                                <div class="row-fluid">
								    
                                   
								   <button onclick="$('.overlay#editStatusInGroupsInner').trigger('hide');return false;" id="CloseMeatEDIT" class="btn btn-danger submt-btn">Close</button>
								   
								   <input type="submit" class="btn btn-success submt-btn" />
									 <input type="hidden" id="editPostId" value="" />
                                </div>
                            </form>
                       
                    </div>
                </div>
                <!-- /SECTION TILES -->

      
      </div>
    </div>
	
	
	
	
	
	
	
		<div class="overlay" id="editEventSection">
      <div class="modal1" style="background:rgba(0,0,0,0.9); width: 30%;height:55%;padding: 1%;box-shadow: 0px 4px 15px 2px rgba(19, 21, 24, 0.4);">
	<div class="simp-cls" style="position:absolute;top:0">  <a href="#!"  onclick="$('.overlay#editEventSection').trigger('hide');return false;" >x</a></div>
         

                <!-- SECTION TITLE -->
               
                <!-- /SECTION TITLE -->

                <!-- SECTION TILES -->
                <div class="tile black htmltile w3 h4" style="width:95%; margin-top:3px; height:100%">
                    <div class="tilecontent">
					 <h3 class="block-title" style="margin-top: 15px;
margin-left: 9px;">Edit Event</h3>
                            <form id="contactme" class="form-dark" name="cform" method="post" action="">
                               
								 <div class="row-fluid"  style="margin-top:15px;">
                                    <label>Event Title </label>
                                    <input type="text" class="span12" id="eventTitleEdit" name="eventTitleEdit" placeholder="Event title">
                                </div>
								
								<div class="row-fluid"  >
                                    <label>Location</label>
                                   
									<input type="text" class="span12" id="eventLocationEdit" name="eventLocationEdit" placeholder="Event location" /> 
                                </div>
                               
							   <div class="row-fluid"  >
                                    <label>Event date</label>
                                   
									<input type="text" class="span12 eventDate" id="eventDateEdit" name="eventDateEdit" placeholder="Event date" placeholder="Event date" /> 
                                </div>
							   
							   
							   <div class="row-fluid"  >
                                    <label>Event description</label>
                                    <textarea class="span12" name="eventDesEdit" id="eventDesEdit" placeholder="Tell about event..."></textarea>
                                </div>
                            
                                <div class="row-fluid">
								    
                                   
								   <button onclick="$('.overlay#editEventSection').trigger('hide');return false;" id="closeMeatEventedit" class="btn btn-danger submt-btn">Close</button>
								   
								   <button type="submit" id="eventEditsubmit" class="btn btn-success submt-btn">Update</button>
									  <input type="hidden" id="eventPostId" value="" />
                                </div>
                            </form>
                       
                    </div>
                </div>
                <!-- /SECTION TILES -->

      
      </div>
    </div>
	
	
	
	
	
	
	

	<div class="overlay" id="forDelete">
      <div class="modal1" style="background:rgba(0,0,0,0.9); width: 12%;height: 20%;padding: 2%;box-shadow: 0px 4px 15px 2px rgba(19, 21, 24, 0.4);">
	<div class="simp-cls" style="position:absolute;top:0">  <a href="#!"  onclick="$('.overlay#forDelete').trigger('hide');return false;" >x</a></div>
         

                
               

                <!-- SECTION TILES -->
              
					<h3 class="block-title" style="">Delete confirmation</h3>
					<p style="margin:20px">Do you want to delete?</p>
                  
					<div class="row-fluid" id="">
                                    <input type="submit"  value='Yes' class="btn btn-success btn-delete-ys" id="deleteConfirmBtn" />
									<input onclick="$('.overlay#forDelete').trigger('hide');return false;" type="submit" id="NoDelete"  value='No'  class="btn btn-danger btn-delete-ys" /> 
                                </div>
      
      </div>
    </div>
	<script>
$(document).ready(function(){
		$("#mahajyothis_search").change(function(){
			
			setTimeout(function(){
			
			
	var name=$("#mahajyothis_search").val();
	if(name!='No User Found' & name.length >3){
	var groupID=<?php echo $this->session->userdata['groupID']; ?>;
	if(name!=''){
		$.ajax({
          url: "<?php echo base_url();?>groups/invitations?name="+name+"&gid="+groupID
        }).done(function( data ) {
		$("#invitebutton").hide();
		$("#mahajyothis_search").val('');
		$("#sent_information").html("<font color='white'>"+name+" </font><font color='yellow'>has been added...</font>").show();
		  return true;
        }); 
		}
	if(name==''){
		$("#mahajyothis_search").focus();	
	return false;
	}}
	}, 100 );
});
	});

</script>
	
 <script>
  $(document).ready(function(){
    $("body").hide(0).delay(0).slideDown(600)
    });
 
      $(document).ready(function() {
        $('.overlay').overlay();
      });
    </script>
<script>
$(document).ready(function() {

 $('#cmnt-area').hide();
  $('#up-fle').hide();
   $('#add-pst-vide').hide();
    $('#event-frmm').hide();

  $('#cmnt-boxx').css('cursor','pointer');
    $('#cmnt-boxx').click(function() {
        $('#cmnt-area').slideToggle();
    });
	
    $('#pst-even-mnu').click(function() {
         $('#add-pst-vide').hide();
		  $('#pst-dsply-blck').hide();
    $('#event-frmm').show();
    });
	 $('#pst-dsply-mnu').click(function() {
         $('#add-pst-vide').hide();
		  $('#pst-dsply-blck').show();
    $('#event-frmm').hide();
    });
	 $('#pst-img-mnu').click(function() {
         $('#add-pst-vide').show();
		  $('#pst-dsply-blck').hide();
    $('#event-frmm').hide();
    });
	
	
	 $('#write-something-cmnt').click(function() {
       
		$('#up-fle').show();
		
    });
	

	
});
</script>

	     <?php include_once('assets/group_rakesh/js/groups.php');?>
		 <script src="<?php echo base_url('assets/group_rakesh/js/jquery-ui.js');?>"></script>
		 <script src="<?php echo base_url('assets/group_rakesh/js/script.js');?>"></script>
    </body>
</html>