<!doctype html>
<html lang="en">
    <head>       
        <meta charset="utf-8" />
        <title>.:: Mahajyothis groups ::.</title>
        
        <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1, maximum-scale=1, user-scalable=no">

        <!--[if lt IE 9]><script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->

		  
          <script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
		
    <script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.2/js/bootstrap.min.js"></script>
    <script src="https://google-code-prettify.googlecode.com/svn/loader/run_prettify.js"></script>
		
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:300,600' rel='stylesheet' type='text/css'>
		
		
		<link href="<?php echo base_url('assets/grouppage/css/overlay.css');?>" rel="stylesheet">
		<link href="<?php echo base_url('assets/grouppage/css/style.css');?>" rel="stylesheet">
		<link href="<?php echo base_url('assets/grouppage/css/style-groups.css');?>" rel="stylesheet">
        <link href="<?php echo base_url('assets/grouppage/css/bootstrap-cols.css');?>" rel="stylesheet">
 
     
         <script src="<?php echo base_url('assets/grouppage/js/jquery.isotope.min.js');?>" type="text/javascript"></script> <!-- jQuery Library -->
         <script src="<?php echo base_url('assets/grouppage/js/jquery.mousewheel.js');?>" type="text/javascript"></script> <!-- jQuery Library -->
         <script src="<?php echo base_url('assets/grouppage/js/tileshow.js');?>" type="text/javascript"></script> <!-- jQuery Library -->
         <script src="<?php echo base_url('assets/grouppage/js/script.js');?>" type="text/javascript"></script> <!-- jQuery Library -->
         
		 <script src="<?php echo base_url('assets/grouppage/js/overlay.js');?>" type="text/javascript"></script> <!-- jQuery Library -->
         
		  <script src="<?php echo base_url('assets/grouppage/js/jquery.mCustomScrollbar.js');?>" type="text/javascript"></script>
		  <script src="<?php echo base_url('assets/grouppage/js/jquery.confirm.js');?>" type="text/javascript"></script>
       
    </head>
    <body>
	
 <?php $user_row = $this->session->userdata('profile_data'); ?>

        <div class="header" style='z-index:999;'>
            <div class="icn-bck-clsss">
								<a style="cursor:pointer;" href="<?php echo base_url('user/'.$user_row[0]['custName']);?>">	<i class="fa fa-arrow-circle-o-left fa-4x"></i></a>
									<span style="font-size: 40px;
    padding: 44px;">Groups</span>
	
	<a data-overlay-trigger="two" href="#!"><span class="rht-tp-icn"> <img src="<?php echo base_url('assets/grouppage/img/icon Group page.png');?>"></span></a>
	
								</div>
        </div>
        
        <section id="content">

            
            <section class="clearfix section" id="about">

                <!-- SECTION TITLE -->
                <h3 class="block-title"></h3>
                <!-- /SECTION TITLE -->

                <!-- SECTION TILES -->
             

                <div class="tile black htmltile w3 h4">
                    <div class="tilecontent">
					
                        <div class="content">
						
						<div class="thumbnail" style="float:left;width: 35.6%; border:none; padding:0;" >
                      
						 <img style="float:left;width:140px;height:140px;" src='<?php if(isset($user_row[0]['photo'])){echo base_url('uploads').'/'.$user_row[0]['photo'];}else{echo base_url('uploads').'/profile.png';} ?>' style="float:left" class="img-responsive" />
						
                  </div>
				  <div style="    padding-left: 15px;
    float: left;
    width: 60%; height:130px; background: rgba(11, 7, 7, 0.35);padding-top: 11px; ">
                            
									
									 <h3><?php echo $user_row[0]['perdataFirstName'] ."&nbsp;"  .$user_row[0]['perdataLastName']; ?></h3>
									  <h4 class="muted"><?php echo $user_row[0]['profProfession'];  ?></h4>
									<span class="loc-txt-grp"  style="padding-right: 0px;"><?php echo $login =$user_row[0]['addrDistrict'];  ?>, <?php echo $login =$user_row[0]['addrState'];  ?></span></p>
								
									 <p class="fnt-clr-clss">
                                       <?php  echo $login =$user_row[0]['perdataAboutMe'];   ?>
									 
                                      </p>
									
									</div>
                            <ul class="grups-lst">
									<li class="col-md-12 no-pad-grp">
											<div class="grp-centrd-txt icn-bck-btnn" style="    float: left;
    width: 12%;
    margin: 0;">
												<img src="<?php echo base_url('assets/grouppage/img/public group icon.png');?>">
											</div>
											<div class="hvr-cls-grp own-grp" id="owner-button" style="width: 75.9%;float: left;margin-bottom:0 "><span style="margin-bottom:0">Own Groups</span></div>
									</li>
									
									
									<li class="col-md-12 no-pad-grp">
											<div class=" grp-centrd-txt icn-bck-clsss icn-bck-btnn" style=" float: left;
    width: 12%;
    margin: 0;">
												<img src="<?php echo base_url('assets/grouppage/img/public group icon.png');?>">
											</div>
											<div class=" hvr-cls-grp netwrk-grp"  id="network-button"  style="width: 75.9%;float: left;margin-bottom:0 "><span style="margin-bottom:0">Network Groups</span></div>
									</li>
									<li class="col-md-12 no-pad-grp">
											<div class="cgrp-centrd-txt icn-bck-clsss icn-bck-btnn"  style="float: left;width:12%; margin:0">
											<img src="<?php echo base_url('assets/grouppage/img/public group icon.png');?>">
											</div>
											<div class=" hvr-cls-grp suggst-grp" id="suggest-button" style="width: 75.9%;float: left;margin-bottom:0 "><span style="margin-bottom:0">Suggest Groups</span></div>
									</li>
								</ul>
                        </div>
                    </div>
                </div>
                <!-- /SECTION TILES -->

            </section>
            
							
            <section class="clearfix section" id="own-groups">

                <!-- SECTION TITLE -->
                <h3 class="block-title">Own Groups</h3> 
                <!-- /SECTION TITLE -->

                <!-- SECTION TILES -->
				 <?php  
							
							    if(empty($results_own))
                                {
	
								   echo "No data found...!";
								}
								else
								{
                                 
								foreach($results_own as $result)
						         {
						     ?>
             <div class="tile white title-scaleup imagetile w2 h1" style="height:86px" id="group_<?php echo $result->grp_id; ?>">
                  <div class="col-md-12 no-pad-grp bck-clr-cls">
					<div class="col-md-4 nor-4 no-pad-grp">
					   <div class="bck-attr-clr"></div>
						  <div class="img-rht-clsss-grp thumbnail">
						    <img src="<?=base_url()."uploads/groups/banners/".$result->grp_cover;?>" class="img-responsive" >
								</div>
									</div>
                                            <div class="col-md-8 nor-8 no-pad-grp">
												<div class="cntnt-rht-clsss-grp" style="padding-left:7px">
													<a href="<?php echo base_url().'groups/view/'.$this->custom_function->create_ViewUrl($result->grp_id,$result->grp_name); ?>"><h4 class="fnt-clr-clss-title"><?=$result->grp_name;?></h4></a>
													<p class="mrgn-btm-cls"><span>Members</span> <span ><i class="fa fa-users"style="color:#fff"></i></span> (<span>1000</span>)</p>
													
													<p   class="mrgn-btm-cls1"><?php if($result->privacy ==1) { echo 'Public'; } else { echo 'Private'; } ?> Group</p>
													
													<div class="grp-rht-clss" id='<?=$result->grp_id;?>'><a class='editData' data-overlay-trigger="one" href="#!"><span class="icn-spce-grp"><i class="fa fa-pencil-square-o" style="color:#fff"></i></span>
													<span  class="textcnt-spce-grp fnt-clr-clss">Edit</span>
													</a>
													
													<a href='#'><span  class="icn-spce-grp"><i class="fa fa-trash-o" style="color:#fff"></i></span><span class="fnt-clr-clss" id="complexConfirm_<?=$result->grp_id;?>">Delete</span>
													</a>
													</div>
												
												
												
												</div>
											</div>
									</div>
									
									
								
									
                </div>
		
				
				
				
                 <script>
           
                $("#complexConfirm_<?=$result->grp_id;?>").confirm({
                title:"<h3>Delete confirmation</h3>",
                text: "Do you want to delete this group?",
                confirm: function(button) {
                    button.fadeOut(2000).fadeIn(2000);
					var dataString = 'id='+<?=$result->grp_id;?>;
				    
					$.ajax({
					type: "POST",
					url: '<?php echo base_url();?>groups/delete',
					data: dataString,
					cache: false,
					success: function(data){
						data = parseInt(data);
						if(data === 1) {
							
							location.reload();
							
						}
						else alert('Some error occured. Please try again'); 
						
					}
				    });
                },
                cancel: function(button) {
                    button.fadeOut(1000).fadeIn(1000);
                },
                confirmButton: "Yes",
                cancelButton: "No"
            });
            
            </script>
				<?php 
				   } 
				  }
				?>
                <!-- /SECTION TILES -->

            </section>
			  <section class="clearfix section" id="network-groups">

                <!-- SECTION TITLE -->
                <h3 class="block-title">Network Groups</h3>
                <!-- /SECTION TITLE -->
                <?php  
							
							    if(empty($network_groups))
                                {
	
								   echo "No data found...!";
								}
								else
								{
                                 
								foreach($network_groups as $result)
						         {
						     ?>
                <!-- SECTION TILES -->
                <div class="tile white title-scaleup imagetile w2 h1" style="height:86px" id="group_<?php echo $result->grp_id; ?>">
                   <div class="col-md-12 no-pad-grp bck-clr-cls">
									
									<div class="col-md-4 nor-4 no-pad-grp">
								<div class="bck-attr-clr"></div>
											<div class="img-rht-clsss-grp thumbnail">
												 <img src="<?=base_url()."uploads/groups/banners/".$result->grp_cover;?>" class="img-responsive" >
											</div>
									</div>
											<div class="col-md-8 nor-8 no-pad-grp">
												<div class="cntnt-rht-clsss-grp" style="padding-left:7px">
													<h5 class="fnt-clr-clss-title"><?=$result->grp_name;?></h5>
													<p class="mrgn-btm-cls"><span>Members</span> <span ><i class="fa fa-users"style="color:#fff"></i></span> (<span>1000</span>)</p>
													<p   class="mrgn-btm-cls1"><?php if($result->privacy ==1) { echo 'Public'; } else { echo 'Private'; } ?> Group</p>
													<div class="grp-rht-clss">
													
												<a href="<?php echo base_url().'groups/view/'.$this->custom_function->create_ViewUrl($result->grp_id,$result->grp_name); ?>"><i class="fa fa-pencil-square-o" style="color:#fff"></i></span><span  class="textcnt-spce-grp fnt-clr-clss">Visit now</span></a>
													
													</div>
												</div>
											</div>
									</div>
                </div>
                  <?php }  } ?>
				
                <!-- /SECTION TILES -->

            </section>
			  <section class="clearfix section" id="suggest-groups">

                <!-- SECTION TITLE -->
                <h3 class="block-title">Suggest Groups</h3>
                <!-- /SECTION TITLE -->
                      <?php  
							
							    if(empty($results_public))
                                {
								   
								   echo "No data found...!";
								}
								else
								{
                                 
								foreach($results_public as $result)
						         {
						     ?>
                <!-- SECTION TILES -->
                <div class="tile white title-scaleup imagetile w2 h1" style="height:86px">
                   <div class="col-md-12 no-pad-grp bck-clr-cls">
									
									<div class="col-md-4 nor-4 no-pad-grp">
								<div class="bck-attr-clr"></div>
											<div class="img-rht-clsss-grp thumbnail">
												 <img src="<?=base_url()."uploads/groups/banners/".$result->grp_cover;?>" class="img-responsive" >
											</div>
									</div>
											<div class="col-md-8 nor-8 no-pad-grp">
												<div class="cntnt-rht-clsss-grp" style="padding-left:7px">
													<h5 class="fnt-clr-clss-title"><?=$result->grp_name;?></h5>
													
													<p class="mrgn-btm-cls"><span>Members</span> <span ><i class="fa fa-users"style="color:#fff"></i></span> (<span> 0 </span>)</p>
													
													<p   class="mrgn-btm-cls1"><?php if($result->privacy ==1) { echo 'Public'; } else { echo 'Private'; } ?> Group</p>
													
													<div class="grp-rht-clss"><span class="icn-spce-grp">
													
													<a href="<?php echo base_url().'groups/view/'.$this->custom_function->create_ViewUrl($result->grp_id,$result->grp_name); ?>"><i class="fa fa-pencil-square-o" style="color:#fff"></i></span><span  class="textcnt-spce-grp fnt-clr-clss">Visit and Join</span></a>
													
													
													
													</div>
												</div>
											</div>
									</div>
                </div>
				
				
				<?php 
				    }
				   }
				?>
				 <div></div>
				
                <!-- /SECTION TILES -->

            </section>
            <!-- /SECTION -->

        </section> 
		
        <!-- /MAIN CONTENT SECTION -->
<div class="overlay" id="one" style='z-index:9999;'>
      <div class="modal1">
	<div class="simp-cls">  <a href="#!"  onclick="$('.overlay#one').trigger('hide');return false;">x</a></div>
         

                <!-- SECTION TITLE -->
                <h3 class="block-title" style="margin-top: 1px;
margin-left: 9px;">Edit Group</h3>
                <!-- /SECTION TITLE -->

                <!-- SECTION TILES -->
                <div class="tile black htmltile w3 h4" style="width:95%; margin-top:3px; height:100%">
                    <div class="tilecontent">
						

                            

                           

                            <form id="contactme" action="<?php echo base_url().'groups/update';?>" enctype="multipart/form-data" class="form-dark" name="cform" method="post" >
                                <div class="row-fluid"  style="margin-top:15px;">
                                    <label>Group Name </label>
                                    <input type="text" class="span12" placeholder="Group Name" name="edit_groupTitle" id="EditgroupTitle">
                                </div>
								<div class="row-fluid"  >
                                    <label>Group Description</label>
                                    <textarea class="span12" name="edit_groupDes" id="EditgroupDes" placeholder="Group Discussion"></textarea>
                                </div>
                                <div class="row-fluid">
                                    <label>Group Image: </label>
                                   <div id="img_container" style='padding:10px;'></div>
									<input type="file" name="edit_groupCover" accept='image/*' id="EditgroupCover">
                                </div>
                               
                                <div class="row-fluid">
                                    <label>Privacy</label>
                                    <select class="span12"  name="edit_groupPrivacy" id="EditgroupPrivacy">
			                          <option value='1'>Public</option>
			                          <option value='2'>Private</option>
			                       </select>
									<input type="hidden" id="EditGroupId" value="" name="edit_groupid" />
                                </div>

                               
                                <div class="row-fluid">
                                    <button type="submit" id='i_submit' class="btn btn-success pull-right">Update</button>
                                </div>
                            </form>
                       
                    </div>
                </div>
                <!-- /SECTION TILES -->

      
      </div>
    </div>
	<div class="overlay" id="two" style='z-index:9999;'>
      <div class="modal1" style="width:30%; height:65%">
	<div class="simp-cls">  <a href="#!"  onclick="$('.overlay#two').trigger('hide');return false;">x</a></div>
         <h3 class="block-title" style="margin-top: 1px;
margin-left: 9px;">Create new Group</h3>
                <!-- /SECTION TITLE -->

                <!-- SECTION TILES -->
                <div class="tile black htmltile w3 h4" style="width:95%; margin-top:3px; height:100%">
                    <div class="tilecontent">
				
                     <form class="form-dark" name="cform" method="post" enctype="multipart/form-data" action="<?php echo base_url().'groups/add';?>">
                                <div class="row-fluid"  style="margin-top:15px;">
                                    <label>Group Name </label>
                                     <input type="hidden" required class="form-control" name="userID" id="userID" value="<?php echo $user_row[0]['custID'];?>">
									<input type="text" class="span12" name="groupTitle" id="groupTitle" required placeholder="Group Name">
                                </div>
								<div class="row-fluid"  >
                                    <label>Group description</label>
                                    <textarea class="span12" placeholder="Group description" name="groupDes" id="groupDes" required></textarea>
                                </div>
                                <div class="row-fluid">
                                    <label>Group Image: <small style='color:red;font-style:italic;'>(300x300)*</small> </label>
                                   <div id="uploadPreviewCreate" style='padding:10px;'>
								   <img style='background-color:#fff;' id='def_grp_img' width='100' src="<?=base_url()."uploads/groups/banners/groups_def.png"?>" class="img-responsive" >
								   </div>
									<input type="file" name="groupCover" id="groupCover" accept='image/*' />
                                </div>
                               
                                <div class="row-fluid">
                                    <label>Privacy</label>
                                    <select name="groupPrivacy" id="groupPrivacy" class="span12">
                                        <option value='1'>Public</option>
			                            <option value='2'>Private</option>
                                        
                                    </select>
                                </div>

                               
                                <div class="row-fluid">
                                    <button type="submit" class="btn btn-info pull-right">Submit</button>
                                </div>
                            </form>
                       
                    </div>
                </div>
	</div>
	</div>
      
       

    
   
		
 <script>
     $(document).ready(function(){
    $("body").hide(0).delay(0).fadeIn(500)
    });
      $(document).ready(function() {
	   
	   
	  
        $('.overlay').overlay();
		
		
		
      });
    </script>
	
		
<script>
$(document).ready(function() {

    $(document).on('click','.editData',function(e){
		var exampleModalGroupEdit = $('#one');
		var id = $(this).parent().attr('id');
		//alert('edit clicked'+id);
			//var id = $(this).parent().attr('id');
			var dataString = 'getData=true'+'&id='+id;
				$.ajax({
					type: "POST",
					url: "groups/get_group_data",
					data: dataString,
					cache: false,
					success: function(data){
						if(data) {			
							    exampleModalGroupEdit.find('#EditGroupId').val(data.grp_id);
								exampleModalGroupEdit.find('#EditgroupTitle').val(data.grp_name);
								exampleModalGroupEdit.find('#EditgroupDes').val(data.grp_description);
								exampleModalGroupEdit.find('#img_container').html('<img width="100" id="img_preview" src="<?= base_url()."uploads/groups/banners/";?>'+data.grp_cover+'" alt="'+data.grp_name+'"></img>');
								exampleModalGroupEdit.find('select option[value='+data.privacy+']').prop('selected', true); 
								
							//	alert(data.grp_name);
						}
						else alert('Some error occured. Please try again'); 
						
					}
				}); 
			
		});

 $('#network-groups').hide();
 $('#suggest-groups').hide();
    $('#owner-button').click(function() {
        $('#network-groups').hide();
       $('#suggest-groups').hide(); 
		$('#own-groups').show(); 
  
    });
	 $('#network-button').click(function() {
        $('#network-groups').show();
       $('#suggest-groups').hide(); 
		$('#own-groups').hide(); 	   
    });
	 $('#suggest-button').click(function() {
        $('#network-groups').hide();
       $('#suggest-groups').show(); 
		$('#own-groups').hide(); 	   
    });

	
});
</script>

<script>
// var url = window.URL || window.webkitURL; // alternate use

function readImage(file,nameElement) {
    var input = $('#'+nameElement);
    var reader = new FileReader();
    var image  = new Image();
  
    reader.readAsDataURL(file);  
    reader.onload = function(_file) {
        image.src    = _file.target.result;              // url.createObjectURL(file);
        image.onload = function() {
            var w = this.width,
                h = this.height,
                t = file.type,                           // ext only: // file.type.split('/')[1],
                n = file.name,
                s = ~~(file.size/1024) +'KB';
				
				
				if(w > 300 && h > 300)
				{
				  alert('Please upload file with 300x300 sizes');
				  input.replaceWith(input.val('').clone(true));
				  return false;
				}
		       if(nameElement == 'groupCover')
			   {
               $('#def_grp_img').fadeOut();
               $('#uploadPreviewCreate').append('<img width="100" src="'+ this.src +'">');
			   }
			   else
			   {
			         $( "#img_container" ).empty();
			        $('#img_container').append('<img width="100" src="'+ this.src +'">');
			   }
        };
           image.onerror= function() {
            alert('Invalid file type: '+ file.type);
         };      
    };
    
}
$("#groupCover").change(function (e) {
    if(this.disabled) return alert('File upload not supported!');
    var F = this.files;
    if(F && F[0]) for(var i=0; i<F.length; i++) readImage( F[i],'groupCover' );
});

$("#EditgroupCover").change(function (e) {
    if(this.disabled) return alert('File upload not supported!');
    var F = this.files;
    if(F && F[0]) for(var i=0; i<F.length; i++) readImage( F[i],'EditgroupCover' );
});

</script>

    </body>
</html>