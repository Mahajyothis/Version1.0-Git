<?php
if($results) foreach($results as $result);
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<meta charset="utf-8">
		<title><?php echo $result->titleDis;?></title>
		<meta name="generator" content="Bootply" />
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		  	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
				<link href="<?php echo base_url('assets/dis/Inner/css/styles.css');?>" rel="stylesheet">
		
		<!--[if lt IE 9]>
			<script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
            <script src="http://code.jquery.com/jquery-1.8.3.min.js"></script>
            <script src="https://code.jquery.com/jquery-1.7.1.min.js"></script>
            <script src="https://code.jquery.com/jquery-1.7.2.js"></script>
		<![endif]-->
		
	
</head>
	<!--<body onload="display_v_m_c()">-->
    <body>
<div class="wrapper">
    <div class="box">
        <div class="row">
            <!-- sidebar -->
             <div class="column col-sm-2" id="sidebar" style="background-color:#E67E22;">
                <a href="<?php echo base_url()."discussions";?>"><span style="padding-top:10px;padding-left:10px;"><img style="margin-top:30px;" src="<?php echo base_url('assets/dis/img/dis.png');?>" height="50px" /></span></a>
                <ul class="nav">
                    <li class="active"><a href="<?php echo base_url('discussions/my_discussions');?>">My Discussions</a>
                    </li>
                    <li><a href="<?php echo base_url('discussions/public_discussions');?>">Public Discussions</a>
                    </li>
                </ul>
               
            </div>
		   
            <!-- /sidebar --> <!-- main -->
            <div class="column col-sm-10" id="main">
                <div class="padding">
				<div class="row">
        <div class="col-md-4 col-md-offset-3">
            <form action="<?php echo base_url().'discussions/get_search';?>" method="get" class="search-form">
                <div class="form-group has-feedback">
            		<label for="search" class="sr-only">Search</label>
            		<input type="text" class="form-control" name="search" id="search" placeholder="Search discussion...">
              		<span class="glyphicon glyphicon-search form-control-feedback"></span>
            	</div>
            </form>
        </div>
		
            <a style="cursor:pointer;" href="<?php echo base_url('user/'.$this->session->userdata['profile_data'][0]['custName']);?>"><span class="pull-right btn-success" style="background-color:#E67E22;padding-left:3px;padding-right:3px;color:#fff;">X</span></a>       
    </div> 
                    <div class="full col-sm-9"> <!-- content -->
                        <div class="col-sm-12" id="featured">   
                          <div class="page-header text-muted">
                          <a class="dicussion-title-a" href="<?php echo base_url()."discussions/";?>"><span class="glyphicon glyphicon-chevron-left"></span> Back to discussions</a>
                          </div> 
                        </div> <!--/top story-->
                        <div class="row">    
                         <div class="col-sm-12"><img src="<?php echo ($result->photo && file_exists(UPLOADS.$result->photo)) ? base_url().UPLOADS.$result->photo : base_url().UPLOADS.'profile.png';?>" class="img-thumbnail" alt="Cinque Terre" width="150" height="150"></div>
							</div>
							<div class="col-sm-12"> 
                              <h4><?php echo $result->custName;?></h4>
							</div>
					<div class="col-sm-12">
					<div class="row">
					         <h3><?php echo $result->titleDis;?></h3>
                             <p class="readings" >
							 <?php echo $result->bodyDis;?>
							 
							 <?php  if($total_views->num_rows() <1){
                                
                             $views=$this->db->query("insert into views values('','DISCUSSION','".$result->id_dis."','".$this->session->userdata['profile_data'][0]['custID']."')");


}?>
							 </p>
                             </div>
							 <div class="col-sm-12">
                            <span class="label label-info"><span  class="glyphicon glyphicon-comment" ></span><span class="incc"> <?php echo $total_d;?></span> Comments</span>
							
							<span class="label label-danger"><span class="glyphicon glyphicon-time"></span>  <?php echo $this->custom_function->get_notification_time($this->config->item('global_datetime'),$result->dDate);?></span>
                                 <?php
                                 
                                
                                 if($liked->num_rows() >= 1)
                                 {
                                 ?>

                                 <span class="label label-danger"><span class="glyphicon glyphicon-time"></span>Liked</span>
                                 <?php
                                 }
                                 else
                                 {
                                 ?>
                              <span class="liking">   <span id="display_discussion_like" class="label label-danger"><span class="glyphicon glyphicon-time"></span><a href="#" class="like" id="<?php echo $result->id_dis ; ?>">Like</a></span></span>
                                 <?php
                                 }
                                 ?>
                                 <!--<input type="button" class="c" value="click_me">-->
<span class="user" id="<?php echo $result->custID; ?>" ></span>
							</div>
							<div class="col-sm-12">
							 <br>
                            <p class="comment"><b>Comments:</b></p>
	                       </div>
						   <div class="col-sm-12">
                            <p class="idea">Tell Us What You Think!</p>
                               <!--<textarea id="message-text" class="form-control" style="border-radius:0px;background-color:#eee;color:#808008; width: 70%">Hiiii</textarea>-->
                               <!-------------------------------------------------------------------------------->
                               <div class="recent_comment">
                               <?php
                               if($comments->num_rows()>0){
                               foreach($comments->result() as $row)
                               {
                               ?>
                                   <div class="display_comment" id="margin" style=' border: 1px solid #ccc;margin: 1%; width: 81%;border-radius: 10px;'><p style="margin: 0 0 3px;font-size: 13px;"><img src="/uploads/<?php

                                           if(ISSET($row->photo)){
                                               echo $row->photo;
                                           }
                                           else{
                                               echo "profile.png";
                                           }




                                           ?>" width='10%' style='margin:1%;
       width: 32px;
    height: 32px;
    border-radius: 50px;'><?php echo $row->uaDescription;?></div>

                               <?php
                               }}
                               ?>
</div>

                        <p class="d_c"></p>
                           </div>
                               <?php
                               $query = ("SELECT
                                    *
                                    FROM
                                    customermaster cust
                                   left join
                                    personalphoto pp
                                    on pp.custID=cust.custID

                                   left join
                                    useraction tdm
                                    on tdm.custID=cust.custID
                                    where tdm.catID='".$result->id_dis."'order by uaID desc limit 0,5");
                               $select_com = $this->db->query($query);
                               $tot = count($select_com->result());
                               //echo $tot;

                               //if($tot > 4)
                               //{
                               //?>

                               <a href="javascript:void(0);"  class="view_more_comments" style="color: darkgreen; font-weight: bold; display: none;    margin-left: 32px;">view more comments</a>
                               <?php
                               //}
                              // else
                               //{
                               ?>
                               <?php
                               //}
                               ?>
                               <input type="text" id="increment_number" name="increment_number" value="4" style="display: none">
                               <span id="empty_comm" style="color: darkred;font-weight: bold; display: none">Hei Mr please give a comment</span>
                               <input class="five_value" type="text" value="<?php echo $tot;?>" style="display: none">


                               <!-------------------------------------------------------------------------------->


						   <div class="col-md-12">
						    <div class="col-sm-10">	
					<textarea class="form-control" style="border-radius:0px;background-color:#eee;color:#808008;    margin-top: 12px;    margin-bottom: 28px;" id="user_comment"></textarea>

					
	                       </div>
						   <div class="col-md-2 submit" style="margin-top:10px;">
						   <!--<button type="button" class="btn btn-success" id="submit_comment" onclick="comment_submit()">Submit</button>-->
                           <button type="button" class="btn btn-success comment" id="<?php echo $result->id_dis; ?>">Submit</button>
						   </div>
                            </div>
                            </div>
                           </div>
						    </div>
                 </div><!-- /col-9 -->
                </div><!-- /padding -->
            </div>
            <!-- /main -->
        </div>
    </div>
</div>
	<!-- script references -->

<script src="//ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
		
        <!--This script is for like ths discussion -->
        



    <!--<script>
        function display_cc()
        {
            var did = window.location.href.replace(/\D+/g, '' );

            $.ajax
            ({


                url: "<?php /*echo base_url();*/?>Discussions/display_commentssss?did="+did
            }).done(function( data )
            {
                //$("#add_like").html("<?php /*//echo "(".($val[0]['like']+1).")";  */?>");

                //$("#add_discussion_like").html(data);

                $("#display_comment").html(data)
                return true;
                //alert(data);
            });

        }
    </script>-->
<!--<script>
    function display_cc()
    {
        var did = <?php /*echo $result->id_dis; */?>;
        var rowCount = ('#display_comment').find('table td');

        alert(rowCount)

        if(rowCount < 4)
        {
            $(".view_more_comments").hide()
        }
        //alert(did);
        $.ajax
        ({


            url: "<?php /*echo base_url();*/?>Discussions/display_commentssss?did="+did
        }).done(function( data )
        {
            //$("#add_like").html("<?php /*//echo "(".($val[0]['like']+1).")";  */?>");

            //$("#add_discussion_like").html(data);

            $("#display_comment").html(data)

            return true;
            //alert(data);
        });

    }
</script>-->
<script>
    $(document).ready(function(){
        $(".view_more_comments").click(function(){


            //var did = window.location.href.replace(/\D+/g, '' );
            var pathArray = window.location.pathname.split( '/' );
            //var get_num = pathArray[3];
            //var get_value = get_num.split('-');
            //var did = get_value[0];
            var inc = $("#increment_number").val();
            var did ='<?php echo $result->id_dis;?>';
            var curr = $(this);
            // alert(inc);
            $.ajax
            ({


                url: "<?php echo base_url();?>Discussions/display_more_comments?did="+did+"&& inc="+inc
            }).done(function( data )
            {
                //$(".form-control").focus('');
                $(".display_comment").hide()
                $(".d_c").html(data)
                var rowCount = $('.dsplay_ccc td').length;


                if(rowCount < 4)
                {
                    curr.hide()
                }

                return true;
                //alert(data);
            });


        });
    });
</script>
<!--This script is for number increment -->
<script>
    $(document).ready(function(){
        $(".view_more_comments").click(function(){
            var $n = $("#increment_number");
            $n.val(Number($n.val())+4);
        });
    });
</script>

<!--This script is for submit the comment based on discussion -->



<script>


        var five_value = $(".five_value").val();
        if(five_value > 4)
        {
            $(".view_more_comments").show()
        }
        else if(five_value < 4)
        {
            $(".view_more_comments").hide()
        }




</script>

 <?php include_once('assets/js/discussion/script.php');?>

</body>
</html>